﻿namespace Punto_de_ventas
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox_ReciboVenta = new System.Windows.Forms.GroupBox();
            this.label_ReciboDeudaAnterior = new System.Windows.Forms.Label();
            this.label_DuedaAnterior = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label_ReciboFecha = new System.Windows.Forms.Label();
            this.label_ReciboUltimoPago = new System.Windows.Forms.Label();
            this.label_ReciboDeudaTotal = new System.Windows.Forms.Label();
            this.label_ReciboDeuda = new System.Windows.Forms.Label();
            this.label_ReciboNombre = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.label_MensajeCliente = new System.Windows.Forms.Label();
            this.textBox_BuscarClienteVenta = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.dataGridView_ClienteVenta = new System.Windows.Forms.DataGridView();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.label_PaginaVenta = new System.Windows.Forms.Label();
            this.button_VtUltimo = new System.Windows.Forms.Button();
            this.button_VtAnterior = new System.Windows.Forms.Button();
            this.button_VtSiguiente = new System.Windows.Forms.Button();
            this.button_VtPrimero = new System.Windows.Forms.Button();
            this.button_ReciboVenta = new System.Windows.Forms.Button();
            this.label_ProductoAgotado = new System.Windows.Forms.Label();
            this.dataGridView_Ventas = new System.Windows.Forms.DataGridView();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.label_Deuda = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.checkBox_Credito = new System.Windows.Forms.CheckBox();
            this.label47 = new System.Windows.Forms.Label();
            this.textBox_Pagos = new System.Windows.Forms.TextBox();
            this.label_Cambio = new System.Windows.Forms.Label();
            this.label_SuCambio = new System.Windows.Forms.Label();
            this.label_ImportesVentas = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.button_CancelarVenta = new System.Windows.Forms.Button();
            this.button_Cobrar = new System.Windows.Forms.Button();
            this.label32 = new System.Windows.Forms.Label();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.label_MensajeVenta = new System.Windows.Forms.Label();
            this.button_BuscarProducto = new System.Windows.Forms.Button();
            this.textBox_BuscarProductos = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox_Recibo = new System.Windows.Forms.GroupBox();
            this.label_FechaPG = new System.Windows.Forms.Label();
            this.label_ClienteUP = new System.Windows.Forms.Label();
            this.label_ClienteSA = new System.Windows.Forms.Label();
            this.label_ApellidoRB = new System.Windows.Forms.Label();
            this.label_NombreRB = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox_ClienteReporte = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dataGridView_ClienteReporte = new System.Windows.Forms.DataGridView();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBox_BuscarCliente = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBox_Puesto = new System.Windows.Forms.TextBox();
            this.label_Puesto = new System.Windows.Forms.Label();
            this.dateTimePicker1_Fecha_Nac = new System.Windows.Forms.DateTimePicker();
            this.textBox_Apellido1 = new System.Windows.Forms.TextBox();
            this.label_Apellido1 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.radioButton_IngresarEmpleado = new System.Windows.Forms.RadioButton();
            this.button_EliminarClientes = new System.Windows.Forms.Button();
            this.textBox_Tipo_Empleado = new System.Windows.Forms.TextBox();
            this.label_Tipo_Empleado = new System.Windows.Forms.Label();
            this.button_Cancelar = new System.Windows.Forms.Button();
            this.button_GuardarCliente = new System.Windows.Forms.Button();
            this.label_Fecha_Nac = new System.Windows.Forms.Label();
            this.textBox_Area_Empleado = new System.Windows.Forms.TextBox();
            this.label_Area_Empleado = new System.Windows.Forms.Label();
            this.textBox_Nombre1 = new System.Windows.Forms.TextBox();
            this.label_Nombre1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button_ImprCliente = new System.Windows.Forms.Button();
            this.label_PaginasCliente = new System.Windows.Forms.Label();
            this.button_UltimosClientes = new System.Windows.Forms.Button();
            this.button_AnteriosClientes = new System.Windows.Forms.Button();
            this.button_SiguientesClientes = new System.Windows.Forms.Button();
            this.button_PrimerosClientes = new System.Windows.Forms.Button();
            this.dataGridView_Empleado = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label57 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.dataGridView_ProdCompra = new System.Windows.Forms.DataGridView();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.textBox_BuscarPDT = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label_PaginasPDT = new System.Windows.Forms.Label();
            this.button_UltimaPDT = new System.Windows.Forms.Button();
            this.button_AnteriorPDT = new System.Windows.Forms.Button();
            this.button_SiguientePDT = new System.Windows.Forms.Button();
            this.button_PrimeroPDT = new System.Windows.Forms.Button();
            this.dataGridView_Productos = new System.Windows.Forms.DataGridView();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.panelCodigo = new System.Windows.Forms.Panel();
            this.comboBox_Categorias = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.comboBox_DepartamentoPDT = new System.Windows.Forms.ComboBox();
            this.label_DepartamentoPDT = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox_DescripcionPDT = new System.Windows.Forms.TextBox();
            this.label_DescripcionPDT = new System.Windows.Forms.Label();
            this.button_CancelarPDT = new System.Windows.Forms.Button();
            this.button_GuardarPDT = new System.Windows.Forms.Button();
            this.textBox_PrecioVentaPDT = new System.Windows.Forms.TextBox();
            this.label_PrecioVentaPDT = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label45 = new System.Windows.Forms.Label();
            this.textBox_CoprasProductos = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.label29 = new System.Windows.Forms.Label();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.dataGridView_Cat = new System.Windows.Forms.DataGridView();
            this.dataGridView_Dpto = new System.Windows.Forms.DataGridView();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.label_Cat = new System.Windows.Forms.Label();
            this.textBox_Cat = new System.Windows.Forms.TextBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label_Dpto = new System.Windows.Forms.Label();
            this.textBox_Dpto = new System.Windows.Forms.TextBox();
            this.radioButton_Cat = new System.Windows.Forms.RadioButton();
            this.radioButton_Dpto = new System.Windows.Forms.RadioButton();
            this.button_EliminarDpto = new System.Windows.Forms.Button();
            this.button_DptoCancelar = new System.Windows.Forms.Button();
            this.button_CuardarDpto = new System.Windows.Forms.Button();
            this.label26 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.textBox_BuscarDpto = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.label58 = new System.Windows.Forms.Label();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.label_PaginasCompras = new System.Windows.Forms.Label();
            this.button_UltimaCompra = new System.Windows.Forms.Button();
            this.button_AnteriorCompra = new System.Windows.Forms.Button();
            this.button_SiguienteCompra = new System.Windows.Forms.Button();
            this.button_PrimerCompra = new System.Windows.Forms.Button();
            this.dataGridView_ComprasProductos = new System.Windows.Forms.DataGridView();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.label_ImprorteCompras = new System.Windows.Forms.Label();
            this.label_ImportCompra = new System.Windows.Forms.Label();
            this.textBox_PrecioCompra = new System.Windows.Forms.TextBox();
            this.label_PrecioCmpra = new System.Windows.Forms.Label();
            this.button_EliminarCompras = new System.Windows.Forms.Button();
            this.textBox_DescpCompra = new System.Windows.Forms.TextBox();
            this.label_DescpCompra = new System.Windows.Forms.Label();
            this.button_CancelarCompras = new System.Windows.Forms.Button();
            this.button_GuardarCompras = new System.Windows.Forms.Button();
            this.textBox_CantidadCompra = new System.Windows.Forms.TextBox();
            this.label_CantidadCompra = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.textBox_BuscarCompras = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.label56 = new System.Windows.Forms.Label();
            this.button_db = new System.Windows.Forms.Button();
            this.label37 = new System.Windows.Forms.Label();
            this.button_Reporte = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.button_Cageros = new System.Windows.Forms.Button();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.label34 = new System.Windows.Forms.Label();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.groupBox24 = new System.Windows.Forms.GroupBox();
            this.dataGridView_Usuarios = new System.Windows.Forms.DataGridView();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.radioButton_Cajero = new System.Windows.Forms.RadioButton();
            this.radioButton_Admin = new System.Windows.Forms.RadioButton();
            this.label_Contraseña = new System.Windows.Forms.Label();
            this.textBox_Contraseña = new System.Windows.Forms.TextBox();
            this.label_User = new System.Windows.Forms.Label();
            this.textBox_Usuario = new System.Windows.Forms.TextBox();
            this.button_EliminarUsuario = new System.Windows.Forms.Button();
            this.textBox_ApellidoUser = new System.Windows.Forms.TextBox();
            this.label_ApellidoUser = new System.Windows.Forms.Label();
            this.button_CancelarUser = new System.Windows.Forms.Button();
            this.button_GuardarUser = new System.Windows.Forms.Button();
            this.textBox_TelefonoUser = new System.Windows.Forms.TextBox();
            this.label_TelefonoUser = new System.Windows.Forms.Label();
            this.textBox_NombreUser = new System.Windows.Forms.TextBox();
            this.label_NombreUser = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.label54 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.groupBox26 = new System.Windows.Forms.GroupBox();
            this.dataGridView_ProductoCompra = new System.Windows.Forms.DataGridView();
            this.dataGridView_ProductoPrecio = new System.Windows.Forms.DataGridView();
            this.dataGridView_BodegaReporte = new System.Windows.Forms.DataGridView();
            this.groupBox27 = new System.Windows.Forms.GroupBox();
            this.dataGridView_Reporte = new System.Windows.Forms.DataGridView();
            this.dataGridView_CatProductos = new System.Windows.Forms.DataGridView();
            this.groupBox25 = new System.Windows.Forms.GroupBox();
            this.comboBox_Opciones = new System.Windows.Forms.ComboBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.button_Config = new System.Windows.Forms.Button();
            this.button_Compras = new System.Windows.Forms.Button();
            this.button_Dpto = new System.Windows.Forms.Button();
            this.button_Productos = new System.Windows.Forms.Button();
            this.button_Clientes = new System.Windows.Forms.Button();
            this.button_Ventas = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.comboBox_Tipo_Empleado = new System.Windows.Forms.ComboBox();
            this.comboBox_Area_Empleado = new System.Windows.Forms.ComboBox();
            this.comboBox_Puesto = new System.Windows.Forms.ComboBox();
            this.label_BannerGuardado = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox_ReciboVenta.SuspendLayout();
            this.groupBox20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ClienteVenta)).BeginInit();
            this.groupBox19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Ventas)).BeginInit();
            this.groupBox18.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox_Recibo.SuspendLayout();
            this.groupBox_ClienteReporte.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ClienteReporte)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Empleado)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.groupBox16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ProdCompra)).BeginInit();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Productos)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Cat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Dpto)).BeginInit();
            this.groupBox9.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ComprasProductos)).BeginInit();
            this.groupBox14.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.groupBox21.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.groupBox24.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Usuarios)).BeginInit();
            this.groupBox23.SuspendLayout();
            this.groupBox22.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.groupBox26.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ProductoCompra)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ProductoPrecio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_BodegaReporte)).BeginInit();
            this.groupBox27.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Reporte)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_CatProductos)).BeginInit();
            this.groupBox25.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Alignment = System.Windows.Forms.TabAlignment.Bottom;
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Controls.Add(this.tabPage8);
            this.tabControl1.Location = new System.Drawing.Point(-2, 113);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1045, 557);
            this.tabControl1.TabIndex = 34;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox_ReciboVenta);
            this.tabPage1.Controls.Add(this.groupBox20);
            this.tabPage1.Controls.Add(this.groupBox19);
            this.tabPage1.Controls.Add(this.groupBox18);
            this.tabPage1.Controls.Add(this.groupBox17);
            this.tabPage1.Location = new System.Drawing.Point(4, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1037, 531);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox_ReciboVenta
            // 
            this.groupBox_ReciboVenta.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox_ReciboVenta.Controls.Add(this.label_ReciboDeudaAnterior);
            this.groupBox_ReciboVenta.Controls.Add(this.label_DuedaAnterior);
            this.groupBox_ReciboVenta.Controls.Add(this.label48);
            this.groupBox_ReciboVenta.Controls.Add(this.label_ReciboFecha);
            this.groupBox_ReciboVenta.Controls.Add(this.label_ReciboUltimoPago);
            this.groupBox_ReciboVenta.Controls.Add(this.label_ReciboDeudaTotal);
            this.groupBox_ReciboVenta.Controls.Add(this.label_ReciboDeuda);
            this.groupBox_ReciboVenta.Controls.Add(this.label_ReciboNombre);
            this.groupBox_ReciboVenta.Controls.Add(this.label38);
            this.groupBox_ReciboVenta.Controls.Add(this.label39);
            this.groupBox_ReciboVenta.Controls.Add(this.label40);
            this.groupBox_ReciboVenta.Controls.Add(this.label41);
            this.groupBox_ReciboVenta.Controls.Add(this.label42);
            this.groupBox_ReciboVenta.Controls.Add(this.label43);
            this.groupBox_ReciboVenta.Location = new System.Drawing.Point(814, 337);
            this.groupBox_ReciboVenta.Name = "groupBox_ReciboVenta";
            this.groupBox_ReciboVenta.Size = new System.Drawing.Size(217, 188);
            this.groupBox_ReciboVenta.TabIndex = 9;
            this.groupBox_ReciboVenta.TabStop = false;
            // 
            // label_ReciboDeudaAnterior
            // 
            this.label_ReciboDeudaAnterior.AutoSize = true;
            this.label_ReciboDeudaAnterior.Location = new System.Drawing.Point(83, 99);
            this.label_ReciboDeudaAnterior.Name = "label_ReciboDeudaAnterior";
            this.label_ReciboDeudaAnterior.Size = new System.Drawing.Size(34, 13);
            this.label_ReciboDeudaAnterior.TabIndex = 13;
            this.label_ReciboDeudaAnterior.Text = "$0.00";
            // 
            // label_DuedaAnterior
            // 
            this.label_DuedaAnterior.AutoSize = true;
            this.label_DuedaAnterior.Location = new System.Drawing.Point(6, 99);
            this.label_DuedaAnterior.Name = "label_DuedaAnterior";
            this.label_DuedaAnterior.Size = new System.Drawing.Size(77, 13);
            this.label_DuedaAnterior.TabIndex = 12;
            this.label_DuedaAnterior.Text = "Deuda anterior";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(28, 8);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(158, 16);
            this.label48.TabIndex = 11;
            this.label48.Text = "Abarrotes punto de venta";
            // 
            // label_ReciboFecha
            // 
            this.label_ReciboFecha.AutoSize = true;
            this.label_ReciboFecha.Location = new System.Drawing.Point(75, 169);
            this.label_ReciboFecha.Name = "label_ReciboFecha";
            this.label_ReciboFecha.Size = new System.Drawing.Size(0, 13);
            this.label_ReciboFecha.TabIndex = 10;
            // 
            // label_ReciboUltimoPago
            // 
            this.label_ReciboUltimoPago.AutoSize = true;
            this.label_ReciboUltimoPago.Location = new System.Drawing.Point(85, 145);
            this.label_ReciboUltimoPago.Name = "label_ReciboUltimoPago";
            this.label_ReciboUltimoPago.Size = new System.Drawing.Size(34, 13);
            this.label_ReciboUltimoPago.TabIndex = 9;
            this.label_ReciboUltimoPago.Text = "$0.00";
            // 
            // label_ReciboDeudaTotal
            // 
            this.label_ReciboDeudaTotal.AutoSize = true;
            this.label_ReciboDeudaTotal.Location = new System.Drawing.Point(84, 121);
            this.label_ReciboDeudaTotal.Name = "label_ReciboDeudaTotal";
            this.label_ReciboDeudaTotal.Size = new System.Drawing.Size(34, 13);
            this.label_ReciboDeudaTotal.TabIndex = 8;
            this.label_ReciboDeudaTotal.Text = "$0.00";
            // 
            // label_ReciboDeuda
            // 
            this.label_ReciboDeuda.AutoSize = true;
            this.label_ReciboDeuda.Location = new System.Drawing.Point(83, 77);
            this.label_ReciboDeuda.Name = "label_ReciboDeuda";
            this.label_ReciboDeuda.Size = new System.Drawing.Size(34, 13);
            this.label_ReciboDeuda.TabIndex = 7;
            this.label_ReciboDeuda.Text = "$0.00";
            // 
            // label_ReciboNombre
            // 
            this.label_ReciboNombre.AutoSize = true;
            this.label_ReciboNombre.Location = new System.Drawing.Point(83, 53);
            this.label_ReciboNombre.Name = "label_ReciboNombre";
            this.label_ReciboNombre.Size = new System.Drawing.Size(44, 13);
            this.label_ReciboNombre.TabIndex = 6;
            this.label_ReciboNombre.Text = "Nombre";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(9, 169);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(40, 13);
            this.label38.TabIndex = 5;
            this.label38.Text = "Fecha:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(6, 145);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(66, 13);
            this.label39.TabIndex = 4;
            this.label39.Text = "Ultimo pago:";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(6, 53);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(47, 13);
            this.label40.TabIndex = 3;
            this.label40.Text = "Nombre:";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(6, 121);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(74, 13);
            this.label41.TabIndex = 2;
            this.label41.Text = "Deuda actual:";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(6, 77);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(39, 13);
            this.label42.TabIndex = 1;
            this.label42.Text = "Deuda";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(88, 30);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(52, 16);
            this.label43.TabIndex = 0;
            this.label43.Text = "Recibo";
            // 
            // groupBox20
            // 
            this.groupBox20.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox20.Controls.Add(this.label_MensajeCliente);
            this.groupBox20.Controls.Add(this.textBox_BuscarClienteVenta);
            this.groupBox20.Controls.Add(this.label44);
            this.groupBox20.Controls.Add(this.label23);
            this.groupBox20.Controls.Add(this.label24);
            this.groupBox20.Controls.Add(this.dataGridView_ClienteVenta);
            this.groupBox20.Location = new System.Drawing.Point(315, 337);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(493, 188);
            this.groupBox20.TabIndex = 8;
            this.groupBox20.TabStop = false;
            // 
            // label_MensajeCliente
            // 
            this.label_MensajeCliente.AutoSize = true;
            this.label_MensajeCliente.ForeColor = System.Drawing.Color.Crimson;
            this.label_MensajeCliente.Location = new System.Drawing.Point(6, 53);
            this.label_MensajeCliente.Name = "label_MensajeCliente";
            this.label_MensajeCliente.Size = new System.Drawing.Size(0, 13);
            this.label_MensajeCliente.TabIndex = 14;
            // 
            // textBox_BuscarClienteVenta
            // 
            this.textBox_BuscarClienteVenta.Location = new System.Drawing.Point(70, 15);
            this.textBox_BuscarClienteVenta.Multiline = true;
            this.textBox_BuscarClienteVenta.Name = "textBox_BuscarClienteVenta";
            this.textBox_BuscarClienteVenta.Size = new System.Drawing.Size(195, 25);
            this.textBox_BuscarClienteVenta.TabIndex = 13;
            // 
            // label44
            // 
            this.label44.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.SteelBlue;
            this.label44.Location = new System.Drawing.Point(6, 19);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(56, 16);
            this.label44.TabIndex = 12;
            this.label44.Text = "Buscar";
            // 
            // label23
            // 
            this.label23.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.SteelBlue;
            this.label23.Location = new System.Drawing.Point(180, 166);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(60, 16);
            this.label23.TabIndex = 10;
            this.label23.Text = "©PDHN";
            // 
            // label24
            // 
            this.label24.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.SteelBlue;
            this.label24.Image = ((System.Drawing.Image)(resources.GetObject("label24.Image")));
            this.label24.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label24.Location = new System.Drawing.Point(271, 16);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(105, 24);
            this.label24.TabIndex = 2;
            this.label24.Text = "Cliente     ";
            // 
            // dataGridView_ClienteVenta
            // 
            this.dataGridView_ClienteVenta.AllowUserToAddRows = false;
            this.dataGridView_ClienteVenta.AllowUserToDeleteRows = false;
            this.dataGridView_ClienteVenta.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView_ClienteVenta.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_ClienteVenta.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView_ClienteVenta.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_ClienteVenta.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_ClienteVenta.Location = new System.Drawing.Point(6, 76);
            this.dataGridView_ClienteVenta.Name = "dataGridView_ClienteVenta";
            this.dataGridView_ClienteVenta.ReadOnly = true;
            this.dataGridView_ClienteVenta.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_ClienteVenta.Size = new System.Drawing.Size(481, 82);
            this.dataGridView_ClienteVenta.TabIndex = 0;
            // 
            // groupBox19
            // 
            this.groupBox19.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox19.Controls.Add(this.label_PaginaVenta);
            this.groupBox19.Controls.Add(this.button_VtUltimo);
            this.groupBox19.Controls.Add(this.button_VtAnterior);
            this.groupBox19.Controls.Add(this.button_VtSiguiente);
            this.groupBox19.Controls.Add(this.button_VtPrimero);
            this.groupBox19.Controls.Add(this.button_ReciboVenta);
            this.groupBox19.Controls.Add(this.label_ProductoAgotado);
            this.groupBox19.Controls.Add(this.dataGridView_Ventas);
            this.groupBox19.Location = new System.Drawing.Point(315, 64);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(716, 267);
            this.groupBox19.TabIndex = 7;
            this.groupBox19.TabStop = false;
            // 
            // label_PaginaVenta
            // 
            this.label_PaginaVenta.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label_PaginaVenta.AutoSize = true;
            this.label_PaginaVenta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_PaginaVenta.ForeColor = System.Drawing.Color.DarkCyan;
            this.label_PaginaVenta.Location = new System.Drawing.Point(336, 203);
            this.label_PaginaVenta.Name = "label_PaginaVenta";
            this.label_PaginaVenta.Size = new System.Drawing.Size(65, 16);
            this.label_PaginaVenta.TabIndex = 17;
            this.label_PaginaVenta.Text = "Paginas";
            // 
            // button_VtUltimo
            // 
            this.button_VtUltimo.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.button_VtUltimo.Image = ((System.Drawing.Image)(resources.GetObject("button_VtUltimo.Image")));
            this.button_VtUltimo.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_VtUltimo.Location = new System.Drawing.Point(443, 224);
            this.button_VtUltimo.Name = "button_VtUltimo";
            this.button_VtUltimo.Size = new System.Drawing.Size(75, 29);
            this.button_VtUltimo.TabIndex = 16;
            this.button_VtUltimo.Text = "Ultimo";
            this.button_VtUltimo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_VtUltimo.UseVisualStyleBackColor = true;
            // 
            // button_VtAnterior
            // 
            this.button_VtAnterior.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.button_VtAnterior.Image = ((System.Drawing.Image)(resources.GetObject("button_VtAnterior.Image")));
            this.button_VtAnterior.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_VtAnterior.Location = new System.Drawing.Point(281, 224);
            this.button_VtAnterior.Name = "button_VtAnterior";
            this.button_VtAnterior.Size = new System.Drawing.Size(75, 29);
            this.button_VtAnterior.TabIndex = 15;
            this.button_VtAnterior.Text = "Anterior";
            this.button_VtAnterior.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_VtAnterior.UseVisualStyleBackColor = true;
            // 
            // button_VtSiguiente
            // 
            this.button_VtSiguiente.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.button_VtSiguiente.Image = ((System.Drawing.Image)(resources.GetObject("button_VtSiguiente.Image")));
            this.button_VtSiguiente.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_VtSiguiente.Location = new System.Drawing.Point(362, 224);
            this.button_VtSiguiente.Name = "button_VtSiguiente";
            this.button_VtSiguiente.Size = new System.Drawing.Size(75, 29);
            this.button_VtSiguiente.TabIndex = 14;
            this.button_VtSiguiente.Text = "Siguient";
            this.button_VtSiguiente.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_VtSiguiente.UseVisualStyleBackColor = true;
            // 
            // button_VtPrimero
            // 
            this.button_VtPrimero.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.button_VtPrimero.Image = ((System.Drawing.Image)(resources.GetObject("button_VtPrimero.Image")));
            this.button_VtPrimero.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_VtPrimero.Location = new System.Drawing.Point(200, 224);
            this.button_VtPrimero.Name = "button_VtPrimero";
            this.button_VtPrimero.Size = new System.Drawing.Size(75, 29);
            this.button_VtPrimero.TabIndex = 13;
            this.button_VtPrimero.Text = "Primero";
            this.button_VtPrimero.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_VtPrimero.UseVisualStyleBackColor = true;
            // 
            // button_ReciboVenta
            // 
            this.button_ReciboVenta.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ReciboVenta.ForeColor = System.Drawing.Color.Black;
            this.button_ReciboVenta.Image = ((System.Drawing.Image)(resources.GetObject("button_ReciboVenta.Image")));
            this.button_ReciboVenta.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_ReciboVenta.Location = new System.Drawing.Point(577, 214);
            this.button_ReciboVenta.Name = "button_ReciboVenta";
            this.button_ReciboVenta.Size = new System.Drawing.Size(83, 39);
            this.button_ReciboVenta.TabIndex = 12;
            this.button_ReciboVenta.Text = "Imprimir";
            this.button_ReciboVenta.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_ReciboVenta.UseVisualStyleBackColor = true;
            // 
            // label_ProductoAgotado
            // 
            this.label_ProductoAgotado.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label_ProductoAgotado.AutoSize = true;
            this.label_ProductoAgotado.ForeColor = System.Drawing.Color.Red;
            this.label_ProductoAgotado.Location = new System.Drawing.Point(27, 240);
            this.label_ProductoAgotado.Name = "label_ProductoAgotado";
            this.label_ProductoAgotado.Size = new System.Drawing.Size(0, 13);
            this.label_ProductoAgotado.TabIndex = 1;
            // 
            // dataGridView_Ventas
            // 
            this.dataGridView_Ventas.AllowUserToAddRows = false;
            this.dataGridView_Ventas.AllowUserToDeleteRows = false;
            this.dataGridView_Ventas.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView_Ventas.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_Ventas.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_Ventas.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView_Ventas.ColumnHeadersHeight = 25;
            this.dataGridView_Ventas.Location = new System.Drawing.Point(6, 19);
            this.dataGridView_Ventas.Name = "dataGridView_Ventas";
            this.dataGridView_Ventas.ReadOnly = true;
            this.dataGridView_Ventas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_Ventas.Size = new System.Drawing.Size(704, 177);
            this.dataGridView_Ventas.TabIndex = 0;
            // 
            // groupBox18
            // 
            this.groupBox18.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox18.Controls.Add(this.label_Deuda);
            this.groupBox18.Controls.Add(this.label49);
            this.groupBox18.Controls.Add(this.checkBox_Credito);
            this.groupBox18.Controls.Add(this.label47);
            this.groupBox18.Controls.Add(this.textBox_Pagos);
            this.groupBox18.Controls.Add(this.label_Cambio);
            this.groupBox18.Controls.Add(this.label_SuCambio);
            this.groupBox18.Controls.Add(this.label_ImportesVentas);
            this.groupBox18.Controls.Add(this.label27);
            this.groupBox18.Controls.Add(this.label25);
            this.groupBox18.Controls.Add(this.button_CancelarVenta);
            this.groupBox18.Controls.Add(this.button_Cobrar);
            this.groupBox18.Controls.Add(this.label32);
            this.groupBox18.Location = new System.Drawing.Point(6, 64);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(303, 449);
            this.groupBox18.TabIndex = 6;
            this.groupBox18.TabStop = false;
            // 
            // label_Deuda
            // 
            this.label_Deuda.AutoSize = true;
            this.label_Deuda.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Deuda.ForeColor = System.Drawing.Color.SteelBlue;
            this.label_Deuda.Location = new System.Drawing.Point(0, 308);
            this.label_Deuda.Name = "label_Deuda";
            this.label_Deuda.Size = new System.Drawing.Size(102, 39);
            this.label_Deuda.TabIndex = 35;
            this.label_Deuda.Text = "$0.00";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.ForeColor = System.Drawing.Color.Teal;
            this.label49.Location = new System.Drawing.Point(0, 286);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(97, 17);
            this.label49.TabIndex = 34;
            this.label49.Text = "Deudada total";
            // 
            // checkBox_Credito
            // 
            this.checkBox_Credito.AutoSize = true;
            this.checkBox_Credito.Location = new System.Drawing.Point(9, 81);
            this.checkBox_Credito.Name = "checkBox_Credito";
            this.checkBox_Credito.Size = new System.Drawing.Size(62, 17);
            this.checkBox_Credito.TabIndex = 33;
            this.checkBox_Credito.Text = "Credido";
            this.checkBox_Credito.UseVisualStyleBackColor = true;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.ForeColor = System.Drawing.Color.Teal;
            this.label47.Location = new System.Drawing.Point(8, 113);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(68, 17);
            this.label47.TabIndex = 32;
            this.label47.Text = "Pagó con";
            // 
            // textBox_Pagos
            // 
            this.textBox_Pagos.Location = new System.Drawing.Point(6, 133);
            this.textBox_Pagos.Name = "textBox_Pagos";
            this.textBox_Pagos.Size = new System.Drawing.Size(185, 20);
            this.textBox_Pagos.TabIndex = 31;
            // 
            // label_Cambio
            // 
            this.label_Cambio.AutoSize = true;
            this.label_Cambio.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Cambio.ForeColor = System.Drawing.Color.SteelBlue;
            this.label_Cambio.Location = new System.Drawing.Point(4, 245);
            this.label_Cambio.Name = "label_Cambio";
            this.label_Cambio.Size = new System.Drawing.Size(102, 39);
            this.label_Cambio.TabIndex = 30;
            this.label_Cambio.Text = "$0.00";
            // 
            // label_SuCambio
            // 
            this.label_SuCambio.AutoSize = true;
            this.label_SuCambio.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_SuCambio.ForeColor = System.Drawing.Color.Teal;
            this.label_SuCambio.Location = new System.Drawing.Point(4, 223);
            this.label_SuCambio.Name = "label_SuCambio";
            this.label_SuCambio.Size = new System.Drawing.Size(74, 17);
            this.label_SuCambio.TabIndex = 29;
            this.label_SuCambio.Text = "Su cambio";
            // 
            // label_ImportesVentas
            // 
            this.label_ImportesVentas.AutoSize = true;
            this.label_ImportesVentas.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ImportesVentas.ForeColor = System.Drawing.Color.SteelBlue;
            this.label_ImportesVentas.Location = new System.Drawing.Point(6, 178);
            this.label_ImportesVentas.Name = "label_ImportesVentas";
            this.label_ImportesVentas.Size = new System.Drawing.Size(102, 39);
            this.label_ImportesVentas.TabIndex = 27;
            this.label_ImportesVentas.Text = "$0.00";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.Teal;
            this.label27.Location = new System.Drawing.Point(6, 156);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(100, 17);
            this.label27.TabIndex = 26;
            this.label27.Text = "Monto a pagar";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.ForeColor = System.Drawing.Color.Teal;
            this.label25.Location = new System.Drawing.Point(6, 58);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(53, 13);
            this.label25.TabIndex = 21;
            this.label25.Text = "Se vende";
            // 
            // button_CancelarVenta
            // 
            this.button_CancelarVenta.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_CancelarVenta.Image = ((System.Drawing.Image)(resources.GetObject("button_CancelarVenta.Image")));
            this.button_CancelarVenta.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_CancelarVenta.Location = new System.Drawing.Point(154, 384);
            this.button_CancelarVenta.Name = "button_CancelarVenta";
            this.button_CancelarVenta.Size = new System.Drawing.Size(84, 39);
            this.button_CancelarVenta.TabIndex = 14;
            this.button_CancelarVenta.Text = "Cancelar";
            this.button_CancelarVenta.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_CancelarVenta.UseVisualStyleBackColor = true;
            // 
            // button_Cobrar
            // 
            this.button_Cobrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_Cobrar.Image = ((System.Drawing.Image)(resources.GetObject("button_Cobrar.Image")));
            this.button_Cobrar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Cobrar.Location = new System.Drawing.Point(48, 384);
            this.button_Cobrar.Name = "button_Cobrar";
            this.button_Cobrar.Size = new System.Drawing.Size(84, 39);
            this.button_Cobrar.TabIndex = 13;
            this.button_Cobrar.Text = "Cobrar";
            this.button_Cobrar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_Cobrar.UseVisualStyleBackColor = true;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.Navy;
            this.label32.Location = new System.Drawing.Point(6, 29);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(145, 16);
            this.label32.TabIndex = 0;
            this.label32.Text = "Configuración de venta";
            // 
            // groupBox17
            // 
            this.groupBox17.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox17.Controls.Add(this.label_MensajeVenta);
            this.groupBox17.Controls.Add(this.button_BuscarProducto);
            this.groupBox17.Controls.Add(this.textBox_BuscarProductos);
            this.groupBox17.Controls.Add(this.label21);
            this.groupBox17.Controls.Add(this.label22);
            this.groupBox17.ForeColor = System.Drawing.Color.Green;
            this.groupBox17.Location = new System.Drawing.Point(6, 6);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(1025, 52);
            this.groupBox17.TabIndex = 5;
            this.groupBox17.TabStop = false;
            // 
            // label_MensajeVenta
            // 
            this.label_MensajeVenta.AutoSize = true;
            this.label_MensajeVenta.ForeColor = System.Drawing.Color.Crimson;
            this.label_MensajeVenta.Location = new System.Drawing.Point(665, 22);
            this.label_MensajeVenta.Name = "label_MensajeVenta";
            this.label_MensajeVenta.Size = new System.Drawing.Size(0, 13);
            this.label_MensajeVenta.TabIndex = 13;
            // 
            // button_BuscarProducto
            // 
            this.button_BuscarProducto.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_BuscarProducto.ForeColor = System.Drawing.Color.SteelBlue;
            this.button_BuscarProducto.Location = new System.Drawing.Point(572, 17);
            this.button_BuscarProducto.Name = "button_BuscarProducto";
            this.button_BuscarProducto.Size = new System.Drawing.Size(75, 23);
            this.button_BuscarProducto.TabIndex = 12;
            this.button_BuscarProducto.Text = "Buscar";
            this.button_BuscarProducto.UseVisualStyleBackColor = true;
            // 
            // textBox_BuscarProductos
            // 
            this.textBox_BuscarProductos.Location = new System.Drawing.Point(368, 18);
            this.textBox_BuscarProductos.Multiline = true;
            this.textBox_BuscarProductos.Name = "textBox_BuscarProductos";
            this.textBox_BuscarProductos.Size = new System.Drawing.Size(198, 25);
            this.textBox_BuscarProductos.TabIndex = 11;
            // 
            // label21
            // 
            this.label21.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.SteelBlue;
            this.label21.Location = new System.Drawing.Point(306, 20);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(56, 16);
            this.label21.TabIndex = 10;
            this.label21.Text = "Buscar";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.SteelBlue;
            this.label22.Location = new System.Drawing.Point(3, 12);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(113, 31);
            this.label22.TabIndex = 0;
            this.label22.Text = "Ventas ";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox_Recibo);
            this.tabPage2.Controls.Add(this.groupBox_ClienteReporte);
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1037, 531);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox_Recibo
            // 
            this.groupBox_Recibo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox_Recibo.Controls.Add(this.label_FechaPG);
            this.groupBox_Recibo.Controls.Add(this.label_ClienteUP);
            this.groupBox_Recibo.Controls.Add(this.label_ClienteSA);
            this.groupBox_Recibo.Controls.Add(this.label_ApellidoRB);
            this.groupBox_Recibo.Controls.Add(this.label_NombreRB);
            this.groupBox_Recibo.Controls.Add(this.label12);
            this.groupBox_Recibo.Controls.Add(this.label11);
            this.groupBox_Recibo.Controls.Add(this.label10);
            this.groupBox_Recibo.Controls.Add(this.label9);
            this.groupBox_Recibo.Controls.Add(this.label8);
            this.groupBox_Recibo.Controls.Add(this.label7);
            this.groupBox_Recibo.Location = new System.Drawing.Point(868, 370);
            this.groupBox_Recibo.Name = "groupBox_Recibo";
            this.groupBox_Recibo.Size = new System.Drawing.Size(217, 155);
            this.groupBox_Recibo.TabIndex = 4;
            this.groupBox_Recibo.TabStop = false;
            // 
            // label_FechaPG
            // 
            this.label_FechaPG.AutoSize = true;
            this.label_FechaPG.Location = new System.Drawing.Point(75, 133);
            this.label_FechaPG.Name = "label_FechaPG";
            this.label_FechaPG.Size = new System.Drawing.Size(0, 13);
            this.label_FechaPG.TabIndex = 10;
            // 
            // label_ClienteUP
            // 
            this.label_ClienteUP.AutoSize = true;
            this.label_ClienteUP.Location = new System.Drawing.Point(78, 109);
            this.label_ClienteUP.Name = "label_ClienteUP";
            this.label_ClienteUP.Size = new System.Drawing.Size(13, 13);
            this.label_ClienteUP.TabIndex = 9;
            this.label_ClienteUP.Text = "0";
            // 
            // label_ClienteSA
            // 
            this.label_ClienteSA.AutoSize = true;
            this.label_ClienteSA.Location = new System.Drawing.Point(78, 85);
            this.label_ClienteSA.Name = "label_ClienteSA";
            this.label_ClienteSA.Size = new System.Drawing.Size(13, 13);
            this.label_ClienteSA.TabIndex = 8;
            this.label_ClienteSA.Text = "0";
            // 
            // label_ApellidoRB
            // 
            this.label_ApellidoRB.AutoSize = true;
            this.label_ApellidoRB.Location = new System.Drawing.Point(75, 61);
            this.label_ApellidoRB.Name = "label_ApellidoRB";
            this.label_ApellidoRB.Size = new System.Drawing.Size(0, 13);
            this.label_ApellidoRB.TabIndex = 7;
            // 
            // label_NombreRB
            // 
            this.label_NombreRB.AutoSize = true;
            this.label_NombreRB.Location = new System.Drawing.Point(75, 37);
            this.label_NombreRB.Name = "label_NombreRB";
            this.label_NombreRB.Size = new System.Drawing.Size(0, 13);
            this.label_NombreRB.TabIndex = 6;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(9, 133);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(40, 13);
            this.label12.TabIndex = 5;
            this.label12.Text = "Fecha:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 109);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(66, 13);
            this.label11.TabIndex = 4;
            this.label11.Text = "Ultimo pago:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 37);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(47, 13);
            this.label10.TabIndex = 3;
            this.label10.Text = "Nombre:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 85);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(74, 13);
            this.label9.TabIndex = 2;
            this.label9.Text = "Deuda actual:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 61);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 13);
            this.label8.TabIndex = 1;
            this.label8.Text = "Apellido:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(88, 12);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 16);
            this.label7.TabIndex = 0;
            this.label7.Text = "Recibo";
            // 
            // groupBox_ClienteReporte
            // 
            this.groupBox_ClienteReporte.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox_ClienteReporte.Controls.Add(this.label5);
            this.groupBox_ClienteReporte.Controls.Add(this.label4);
            this.groupBox_ClienteReporte.Controls.Add(this.label3);
            this.groupBox_ClienteReporte.Controls.Add(this.dataGridView_ClienteReporte);
            this.groupBox_ClienteReporte.Location = new System.Drawing.Point(315, 370);
            this.groupBox_ClienteReporte.Name = "groupBox_ClienteReporte";
            this.groupBox_ClienteReporte.Size = new System.Drawing.Size(547, 155);
            this.groupBox_ClienteReporte.TabIndex = 3;
            this.groupBox_ClienteReporte.TabStop = false;
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(207, 133);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(134, 16);
            this.label5.TabIndex = 10;
            this.label5.Text = "© BAC Credomatic";
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DarkCyan;
            this.label4.Image = ((System.Drawing.Image)(resources.GetObject("label4.Image")));
            this.label4.ImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.label4.Location = new System.Drawing.Point(211, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(136, 24);
            this.label4.TabIndex = 2;
            this.label4.Text = "Reportes       ";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Green;
            this.label3.Location = new System.Drawing.Point(168, 157);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(207, 18);
            this.label3.TabIndex = 1;
            this.label3.Text = "Abarrotes punto de Ventas";
            // 
            // dataGridView_ClienteReporte
            // 
            this.dataGridView_ClienteReporte.AllowUserToAddRows = false;
            this.dataGridView_ClienteReporte.AllowUserToDeleteRows = false;
            this.dataGridView_ClienteReporte.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView_ClienteReporte.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_ClienteReporte.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView_ClienteReporte.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_ClienteReporte.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView_ClienteReporte.Location = new System.Drawing.Point(6, 43);
            this.dataGridView_ClienteReporte.Name = "dataGridView_ClienteReporte";
            this.dataGridView_ClienteReporte.ReadOnly = true;
            this.dataGridView_ClienteReporte.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_ClienteReporte.Size = new System.Drawing.Size(535, 82);
            this.dataGridView_ClienteReporte.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox4.Controls.Add(this.textBox_BuscarCliente);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.ForeColor = System.Drawing.Color.Green;
            this.groupBox4.Location = new System.Drawing.Point(6, 6);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(1079, 52);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            // 
            // textBox_BuscarCliente
            // 
            this.textBox_BuscarCliente.Location = new System.Drawing.Point(368, 18);
            this.textBox_BuscarCliente.Multiline = true;
            this.textBox_BuscarCliente.Name = "textBox_BuscarCliente";
            this.textBox_BuscarCliente.Size = new System.Drawing.Size(198, 25);
            this.textBox_BuscarCliente.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DarkCyan;
            this.label6.Location = new System.Drawing.Point(306, 20);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 16);
            this.label6.TabIndex = 10;
            this.label6.Text = "Buscar";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkCyan;
            this.label1.Location = new System.Drawing.Point(3, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "Empleados";
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox3.Controls.Add(this.label_BannerGuardado);
            this.groupBox3.Controls.Add(this.comboBox_Puesto);
            this.groupBox3.Controls.Add(this.comboBox_Area_Empleado);
            this.groupBox3.Controls.Add(this.comboBox_Tipo_Empleado);
            this.groupBox3.Controls.Add(this.textBox_Puesto);
            this.groupBox3.Controls.Add(this.label_Puesto);
            this.groupBox3.Controls.Add(this.dateTimePicker1_Fecha_Nac);
            this.groupBox3.Controls.Add(this.textBox_Apellido1);
            this.groupBox3.Controls.Add(this.label_Apellido1);
            this.groupBox3.Controls.Add(this.label33);
            this.groupBox3.Controls.Add(this.radioButton_IngresarEmpleado);
            this.groupBox3.Controls.Add(this.button_EliminarClientes);
            this.groupBox3.Controls.Add(this.textBox_Tipo_Empleado);
            this.groupBox3.Controls.Add(this.label_Tipo_Empleado);
            this.groupBox3.Controls.Add(this.button_Cancelar);
            this.groupBox3.Controls.Add(this.button_GuardarCliente);
            this.groupBox3.Controls.Add(this.label_Fecha_Nac);
            this.groupBox3.Controls.Add(this.textBox_Area_Empleado);
            this.groupBox3.Controls.Add(this.label_Area_Empleado);
            this.groupBox3.Controls.Add(this.textBox_Nombre1);
            this.groupBox3.Controls.Add(this.label_Nombre1);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Location = new System.Drawing.Point(6, 64);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(303, 461);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            // 
            // textBox_Puesto
            // 
            this.textBox_Puesto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Puesto.Location = new System.Drawing.Point(6, 337);
            this.textBox_Puesto.Name = "textBox_Puesto";
            this.textBox_Puesto.Size = new System.Drawing.Size(198, 22);
            this.textBox_Puesto.TabIndex = 28;
            this.textBox_Puesto.TextChanged += new System.EventHandler(this.textBox_Puesto_TextChanged);
            this.textBox_Puesto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_Puesto_KeyPress);
            // 
            // label_Puesto
            // 
            this.label_Puesto.AutoSize = true;
            this.label_Puesto.Location = new System.Drawing.Point(6, 321);
            this.label_Puesto.Name = "label_Puesto";
            this.label_Puesto.Size = new System.Drawing.Size(40, 13);
            this.label_Puesto.TabIndex = 27;
            this.label_Puesto.Text = "Puesto";
            // 
            // dateTimePicker1_Fecha_Nac
            // 
            this.dateTimePicker1_Fecha_Nac.Location = new System.Drawing.Point(4, 388);
            this.dateTimePicker1_Fecha_Nac.Name = "dateTimePicker1_Fecha_Nac";
            this.dateTimePicker1_Fecha_Nac.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1_Fecha_Nac.TabIndex = 26;
            // 
            // textBox_Apellido1
            // 
            this.textBox_Apellido1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Apellido1.Location = new System.Drawing.Point(6, 137);
            this.textBox_Apellido1.Multiline = true;
            this.textBox_Apellido1.Name = "textBox_Apellido1";
            this.textBox_Apellido1.Size = new System.Drawing.Size(198, 21);
            this.textBox_Apellido1.TabIndex = 24;
            this.textBox_Apellido1.TextChanged += new System.EventHandler(this.textBox_Apellido1_TextChanged);
            this.textBox_Apellido1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_Apellido1_KeyPress);
            // 
            // label_Apellido1
            // 
            this.label_Apellido1.AutoSize = true;
            this.label_Apellido1.Location = new System.Drawing.Point(6, 121);
            this.label_Apellido1.Name = "label_Apellido1";
            this.label_Apellido1.Size = new System.Drawing.Size(76, 13);
            this.label_Apellido1.TabIndex = 23;
            this.label_Apellido1.Text = "Primer Apellido";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.Color.DarkCyan;
            this.label33.Location = new System.Drawing.Point(6, 29);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(131, 16);
            this.label33.TabIndex = 21;
            this.label33.Text = "Datos del empleado";
            // 
            // radioButton_IngresarEmpleado
            // 
            this.radioButton_IngresarEmpleado.AutoSize = true;
            this.radioButton_IngresarEmpleado.Location = new System.Drawing.Point(9, 62);
            this.radioButton_IngresarEmpleado.Name = "radioButton_IngresarEmpleado";
            this.radioButton_IngresarEmpleado.Size = new System.Drawing.Size(112, 17);
            this.radioButton_IngresarEmpleado.TabIndex = 19;
            this.radioButton_IngresarEmpleado.TabStop = true;
            this.radioButton_IngresarEmpleado.Text = "Ingresar empleado";
            this.radioButton_IngresarEmpleado.UseVisualStyleBackColor = true;
            this.radioButton_IngresarEmpleado.CheckedChanged += new System.EventHandler(this.radioButton_IngresarEmpleado_CheckedChanged);
            // 
            // button_EliminarClientes
            // 
            this.button_EliminarClientes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_EliminarClientes.Image = ((System.Drawing.Image)(resources.GetObject("button_EliminarClientes.Image")));
            this.button_EliminarClientes.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_EliminarClientes.Location = new System.Drawing.Point(107, 416);
            this.button_EliminarClientes.Name = "button_EliminarClientes";
            this.button_EliminarClientes.Size = new System.Drawing.Size(84, 39);
            this.button_EliminarClientes.TabIndex = 17;
            this.button_EliminarClientes.Text = "Eliminar";
            this.button_EliminarClientes.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_EliminarClientes.UseVisualStyleBackColor = true;
            // 
            // textBox_Tipo_Empleado
            // 
            this.textBox_Tipo_Empleado.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Tipo_Empleado.Location = new System.Drawing.Point(6, 217);
            this.textBox_Tipo_Empleado.Name = "textBox_Tipo_Empleado";
            this.textBox_Tipo_Empleado.Size = new System.Drawing.Size(198, 22);
            this.textBox_Tipo_Empleado.TabIndex = 16;
            this.textBox_Tipo_Empleado.TextChanged += new System.EventHandler(this.textBox_Tipo_Empleado_TextChanged);
            this.textBox_Tipo_Empleado.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_Tipo_Empleado_KeyPress);
            // 
            // label_Tipo_Empleado
            // 
            this.label_Tipo_Empleado.AutoSize = true;
            this.label_Tipo_Empleado.Location = new System.Drawing.Point(6, 201);
            this.label_Tipo_Empleado.Name = "label_Tipo_Empleado";
            this.label_Tipo_Empleado.Size = new System.Drawing.Size(78, 13);
            this.label_Tipo_Empleado.TabIndex = 15;
            this.label_Tipo_Empleado.Text = "Tipo Empleado";
            // 
            // button_Cancelar
            // 
            this.button_Cancelar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_Cancelar.Image = ((System.Drawing.Image)(resources.GetObject("button_Cancelar.Image")));
            this.button_Cancelar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Cancelar.Location = new System.Drawing.Point(197, 416);
            this.button_Cancelar.Name = "button_Cancelar";
            this.button_Cancelar.Size = new System.Drawing.Size(84, 39);
            this.button_Cancelar.TabIndex = 14;
            this.button_Cancelar.Text = "Cancelar";
            this.button_Cancelar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_Cancelar.UseVisualStyleBackColor = true;
            // 
            // button_GuardarCliente
            // 
            this.button_GuardarCliente.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_GuardarCliente.Image = ((System.Drawing.Image)(resources.GetObject("button_GuardarCliente.Image")));
            this.button_GuardarCliente.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_GuardarCliente.Location = new System.Drawing.Point(17, 416);
            this.button_GuardarCliente.Name = "button_GuardarCliente";
            this.button_GuardarCliente.Size = new System.Drawing.Size(84, 39);
            this.button_GuardarCliente.TabIndex = 13;
            this.button_GuardarCliente.Text = "Guardar ";
            this.button_GuardarCliente.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_GuardarCliente.UseVisualStyleBackColor = true;
            this.button_GuardarCliente.Click += new System.EventHandler(this.button_GuardarCliente_Click);
            // 
            // label_Fecha_Nac
            // 
            this.label_Fecha_Nac.AutoSize = true;
            this.label_Fecha_Nac.Location = new System.Drawing.Point(6, 371);
            this.label_Fecha_Nac.Name = "label_Fecha_Nac";
            this.label_Fecha_Nac.Size = new System.Drawing.Size(93, 13);
            this.label_Fecha_Nac.TabIndex = 5;
            this.label_Fecha_Nac.Text = "Fecha Nacimiento";
            // 
            // textBox_Area_Empleado
            // 
            this.textBox_Area_Empleado.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Area_Empleado.Location = new System.Drawing.Point(6, 289);
            this.textBox_Area_Empleado.Name = "textBox_Area_Empleado";
            this.textBox_Area_Empleado.Size = new System.Drawing.Size(198, 22);
            this.textBox_Area_Empleado.TabIndex = 4;
            this.textBox_Area_Empleado.TextChanged += new System.EventHandler(this.textBox_Area_Empleado_TextChanged);
            this.textBox_Area_Empleado.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_Area_Empleado_KeyPress);
            // 
            // label_Area_Empleado
            // 
            this.label_Area_Empleado.AutoSize = true;
            this.label_Area_Empleado.Location = new System.Drawing.Point(6, 273);
            this.label_Area_Empleado.Name = "label_Area_Empleado";
            this.label_Area_Empleado.Size = new System.Drawing.Size(79, 13);
            this.label_Area_Empleado.TabIndex = 3;
            this.label_Area_Empleado.Text = "Area Empleado";
            // 
            // textBox_Nombre1
            // 
            this.textBox_Nombre1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Nombre1.Location = new System.Drawing.Point(6, 177);
            this.textBox_Nombre1.Multiline = true;
            this.textBox_Nombre1.Name = "textBox_Nombre1";
            this.textBox_Nombre1.Size = new System.Drawing.Size(198, 21);
            this.textBox_Nombre1.TabIndex = 2;
            this.textBox_Nombre1.TextChanged += new System.EventHandler(this.textBox_Nombre1_TextChanged);
            this.textBox_Nombre1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_Nombre1_KeyPress);
            // 
            // label_Nombre1
            // 
            this.label_Nombre1.AutoSize = true;
            this.label_Nombre1.Location = new System.Drawing.Point(6, 161);
            this.label_Nombre1.Name = "label_Nombre1";
            this.label_Nombre1.Size = new System.Drawing.Size(76, 13);
            this.label_Nombre1.TabIndex = 1;
            this.label_Nombre1.Text = "Primer Nombre";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkCyan;
            this.label2.Location = new System.Drawing.Point(6, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(255, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Llene la información del nuevo Empleado";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.button_ImprCliente);
            this.groupBox2.Controls.Add(this.label_PaginasCliente);
            this.groupBox2.Controls.Add(this.button_UltimosClientes);
            this.groupBox2.Controls.Add(this.button_AnteriosClientes);
            this.groupBox2.Controls.Add(this.button_SiguientesClientes);
            this.groupBox2.Controls.Add(this.button_PrimerosClientes);
            this.groupBox2.Controls.Add(this.dataGridView_Empleado);
            this.groupBox2.Location = new System.Drawing.Point(315, 64);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(770, 300);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            // 
            // button_ImprCliente
            // 
            this.button_ImprCliente.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ImprCliente.ForeColor = System.Drawing.Color.Black;
            this.button_ImprCliente.Image = ((System.Drawing.Image)(resources.GetObject("button_ImprCliente.Image")));
            this.button_ImprCliente.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_ImprCliente.Location = new System.Drawing.Point(613, 258);
            this.button_ImprCliente.Name = "button_ImprCliente";
            this.button_ImprCliente.Size = new System.Drawing.Size(83, 39);
            this.button_ImprCliente.TabIndex = 11;
            this.button_ImprCliente.Text = "Imprimir";
            this.button_ImprCliente.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_ImprCliente.UseVisualStyleBackColor = true;
            // 
            // label_PaginasCliente
            // 
            this.label_PaginasCliente.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label_PaginasCliente.AutoSize = true;
            this.label_PaginasCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_PaginasCliente.ForeColor = System.Drawing.Color.DarkCyan;
            this.label_PaginasCliente.Location = new System.Drawing.Point(341, 242);
            this.label_PaginasCliente.Name = "label_PaginasCliente";
            this.label_PaginasCliente.Size = new System.Drawing.Size(65, 16);
            this.label_PaginasCliente.TabIndex = 9;
            this.label_PaginasCliente.Text = "Paginas";
            // 
            // button_UltimosClientes
            // 
            this.button_UltimosClientes.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.button_UltimosClientes.Image = ((System.Drawing.Image)(resources.GetObject("button_UltimosClientes.Image")));
            this.button_UltimosClientes.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_UltimosClientes.Location = new System.Drawing.Point(445, 263);
            this.button_UltimosClientes.Name = "button_UltimosClientes";
            this.button_UltimosClientes.Size = new System.Drawing.Size(75, 29);
            this.button_UltimosClientes.TabIndex = 8;
            this.button_UltimosClientes.Text = "Ultimo";
            this.button_UltimosClientes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_UltimosClientes.UseVisualStyleBackColor = true;
            // 
            // button_AnteriosClientes
            // 
            this.button_AnteriosClientes.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.button_AnteriosClientes.Image = ((System.Drawing.Image)(resources.GetObject("button_AnteriosClientes.Image")));
            this.button_AnteriosClientes.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_AnteriosClientes.Location = new System.Drawing.Point(286, 263);
            this.button_AnteriosClientes.Name = "button_AnteriosClientes";
            this.button_AnteriosClientes.Size = new System.Drawing.Size(75, 29);
            this.button_AnteriosClientes.TabIndex = 7;
            this.button_AnteriosClientes.Text = "Anterior";
            this.button_AnteriosClientes.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_AnteriosClientes.UseVisualStyleBackColor = true;
            // 
            // button_SiguientesClientes
            // 
            this.button_SiguientesClientes.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.button_SiguientesClientes.Image = ((System.Drawing.Image)(resources.GetObject("button_SiguientesClientes.Image")));
            this.button_SiguientesClientes.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_SiguientesClientes.Location = new System.Drawing.Point(367, 263);
            this.button_SiguientesClientes.Name = "button_SiguientesClientes";
            this.button_SiguientesClientes.Size = new System.Drawing.Size(75, 29);
            this.button_SiguientesClientes.TabIndex = 6;
            this.button_SiguientesClientes.Text = "Siguient";
            this.button_SiguientesClientes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_SiguientesClientes.UseVisualStyleBackColor = true;
            // 
            // button_PrimerosClientes
            // 
            this.button_PrimerosClientes.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.button_PrimerosClientes.Image = ((System.Drawing.Image)(resources.GetObject("button_PrimerosClientes.Image")));
            this.button_PrimerosClientes.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_PrimerosClientes.Location = new System.Drawing.Point(205, 263);
            this.button_PrimerosClientes.Name = "button_PrimerosClientes";
            this.button_PrimerosClientes.Size = new System.Drawing.Size(75, 29);
            this.button_PrimerosClientes.TabIndex = 5;
            this.button_PrimerosClientes.Text = "Primero";
            this.button_PrimerosClientes.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_PrimerosClientes.UseVisualStyleBackColor = true;
            // 
            // dataGridView_Empleado
            // 
            this.dataGridView_Empleado.AllowUserToAddRows = false;
            this.dataGridView_Empleado.AllowUserToDeleteRows = false;
            this.dataGridView_Empleado.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView_Empleado.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_Empleado.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_Empleado.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView_Empleado.ColumnHeadersHeight = 25;
            this.dataGridView_Empleado.Location = new System.Drawing.Point(6, 19);
            this.dataGridView_Empleado.Name = "dataGridView_Empleado";
            this.dataGridView_Empleado.ReadOnly = true;
            this.dataGridView_Empleado.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_Empleado.Size = new System.Drawing.Size(758, 210);
            this.dataGridView_Empleado.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label57);
            this.tabPage3.Controls.Add(this.label46);
            this.tabPage3.Controls.Add(this.groupBox16);
            this.tabPage3.Controls.Add(this.groupBox7);
            this.tabPage3.Controls.Add(this.groupBox6);
            this.tabPage3.Controls.Add(this.groupBox5);
            this.tabPage3.Location = new System.Drawing.Point(4, 4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1037, 531);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "tabPage3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label57
            // 
            this.label57.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.ForeColor = System.Drawing.Color.DarkCyan;
            this.label57.Location = new System.Drawing.Point(495, 503);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(60, 16);
            this.label57.TabIndex = 16;
            this.label57.Text = "©PDHN";
            // 
            // label46
            // 
            this.label46.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.ForeColor = System.Drawing.Color.Sienna;
            this.label46.Location = new System.Drawing.Point(703, 226);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(157, 16);
            this.label46.TabIndex = 15;
            this.label46.Text = "Productos en bodega";
            // 
            // groupBox16
            // 
            this.groupBox16.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox16.Controls.Add(this.dataGridView_ProdCompra);
            this.groupBox16.Location = new System.Drawing.Point(315, 64);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(716, 136);
            this.groupBox16.TabIndex = 6;
            this.groupBox16.TabStop = false;
            // 
            // dataGridView_ProdCompra
            // 
            this.dataGridView_ProdCompra.AllowUserToAddRows = false;
            this.dataGridView_ProdCompra.AllowUserToDeleteRows = false;
            this.dataGridView_ProdCompra.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView_ProdCompra.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_ProdCompra.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_ProdCompra.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView_ProdCompra.ColumnHeadersHeight = 25;
            this.dataGridView_ProdCompra.Location = new System.Drawing.Point(6, 19);
            this.dataGridView_ProdCompra.Name = "dataGridView_ProdCompra";
            this.dataGridView_ProdCompra.ReadOnly = true;
            this.dataGridView_ProdCompra.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_ProdCompra.Size = new System.Drawing.Size(704, 111);
            this.dataGridView_ProdCompra.TabIndex = 0;
            // 
            // groupBox7
            // 
            this.groupBox7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox7.Controls.Add(this.textBox_BuscarPDT);
            this.groupBox7.Controls.Add(this.label13);
            this.groupBox7.Controls.Add(this.label_PaginasPDT);
            this.groupBox7.Controls.Add(this.button_UltimaPDT);
            this.groupBox7.Controls.Add(this.button_AnteriorPDT);
            this.groupBox7.Controls.Add(this.button_SiguientePDT);
            this.groupBox7.Controls.Add(this.button_PrimeroPDT);
            this.groupBox7.Controls.Add(this.dataGridView_Productos);
            this.groupBox7.Location = new System.Drawing.Point(315, 258);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(716, 229);
            this.groupBox7.TabIndex = 5;
            this.groupBox7.TabStop = false;
            // 
            // textBox_BuscarPDT
            // 
            this.textBox_BuscarPDT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox_BuscarPDT.Location = new System.Drawing.Point(67, 193);
            this.textBox_BuscarPDT.Multiline = true;
            this.textBox_BuscarPDT.Name = "textBox_BuscarPDT";
            this.textBox_BuscarPDT.Size = new System.Drawing.Size(198, 25);
            this.textBox_BuscarPDT.TabIndex = 11;
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.label13.Location = new System.Drawing.Point(5, 195);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(56, 16);
            this.label13.TabIndex = 10;
            this.label13.Text = "Buscar";
            // 
            // label_PaginasPDT
            // 
            this.label_PaginasPDT.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label_PaginasPDT.AutoSize = true;
            this.label_PaginasPDT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_PaginasPDT.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.label_PaginasPDT.Location = new System.Drawing.Point(405, 171);
            this.label_PaginasPDT.Name = "label_PaginasPDT";
            this.label_PaginasPDT.Size = new System.Drawing.Size(65, 16);
            this.label_PaginasPDT.TabIndex = 9;
            this.label_PaginasPDT.Text = "Paginas";
            // 
            // button_UltimaPDT
            // 
            this.button_UltimaPDT.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.button_UltimaPDT.Image = ((System.Drawing.Image)(resources.GetObject("button_UltimaPDT.Image")));
            this.button_UltimaPDT.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_UltimaPDT.Location = new System.Drawing.Point(512, 192);
            this.button_UltimaPDT.Name = "button_UltimaPDT";
            this.button_UltimaPDT.Size = new System.Drawing.Size(75, 29);
            this.button_UltimaPDT.TabIndex = 8;
            this.button_UltimaPDT.Text = "Ultimo";
            this.button_UltimaPDT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_UltimaPDT.UseVisualStyleBackColor = true;
            // 
            // button_AnteriorPDT
            // 
            this.button_AnteriorPDT.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.button_AnteriorPDT.Image = ((System.Drawing.Image)(resources.GetObject("button_AnteriorPDT.Image")));
            this.button_AnteriorPDT.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_AnteriorPDT.Location = new System.Drawing.Point(350, 192);
            this.button_AnteriorPDT.Name = "button_AnteriorPDT";
            this.button_AnteriorPDT.Size = new System.Drawing.Size(75, 29);
            this.button_AnteriorPDT.TabIndex = 7;
            this.button_AnteriorPDT.Text = "Anterior";
            this.button_AnteriorPDT.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_AnteriorPDT.UseVisualStyleBackColor = true;
            // 
            // button_SiguientePDT
            // 
            this.button_SiguientePDT.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.button_SiguientePDT.Image = ((System.Drawing.Image)(resources.GetObject("button_SiguientePDT.Image")));
            this.button_SiguientePDT.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_SiguientePDT.Location = new System.Drawing.Point(431, 192);
            this.button_SiguientePDT.Name = "button_SiguientePDT";
            this.button_SiguientePDT.Size = new System.Drawing.Size(75, 29);
            this.button_SiguientePDT.TabIndex = 6;
            this.button_SiguientePDT.Text = "Siguient";
            this.button_SiguientePDT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_SiguientePDT.UseVisualStyleBackColor = true;
            // 
            // button_PrimeroPDT
            // 
            this.button_PrimeroPDT.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.button_PrimeroPDT.Image = ((System.Drawing.Image)(resources.GetObject("button_PrimeroPDT.Image")));
            this.button_PrimeroPDT.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_PrimeroPDT.Location = new System.Drawing.Point(269, 192);
            this.button_PrimeroPDT.Name = "button_PrimeroPDT";
            this.button_PrimeroPDT.Size = new System.Drawing.Size(75, 29);
            this.button_PrimeroPDT.TabIndex = 5;
            this.button_PrimeroPDT.Text = "Primero";
            this.button_PrimeroPDT.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_PrimeroPDT.UseVisualStyleBackColor = true;
            // 
            // dataGridView_Productos
            // 
            this.dataGridView_Productos.AllowUserToAddRows = false;
            this.dataGridView_Productos.AllowUserToDeleteRows = false;
            this.dataGridView_Productos.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView_Productos.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_Productos.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_Productos.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView_Productos.ColumnHeadersHeight = 25;
            this.dataGridView_Productos.Location = new System.Drawing.Point(6, 19);
            this.dataGridView_Productos.Name = "dataGridView_Productos";
            this.dataGridView_Productos.ReadOnly = true;
            this.dataGridView_Productos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_Productos.Size = new System.Drawing.Size(704, 139);
            this.dataGridView_Productos.TabIndex = 0;
            // 
            // groupBox6
            // 
            this.groupBox6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox6.Controls.Add(this.panelCodigo);
            this.groupBox6.Controls.Add(this.comboBox_Categorias);
            this.groupBox6.Controls.Add(this.label15);
            this.groupBox6.Controls.Add(this.comboBox_DepartamentoPDT);
            this.groupBox6.Controls.Add(this.label_DepartamentoPDT);
            this.groupBox6.Controls.Add(this.button1);
            this.groupBox6.Controls.Add(this.textBox_DescripcionPDT);
            this.groupBox6.Controls.Add(this.label_DescripcionPDT);
            this.groupBox6.Controls.Add(this.button_CancelarPDT);
            this.groupBox6.Controls.Add(this.button_GuardarPDT);
            this.groupBox6.Controls.Add(this.textBox_PrecioVentaPDT);
            this.groupBox6.Controls.Add(this.label_PrecioVentaPDT);
            this.groupBox6.Controls.Add(this.label19);
            this.groupBox6.Location = new System.Drawing.Point(6, 64);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(303, 392);
            this.groupBox6.TabIndex = 4;
            this.groupBox6.TabStop = false;
            // 
            // panelCodigo
            // 
            this.panelCodigo.Location = new System.Drawing.Point(6, 63);
            this.panelCodigo.Name = "panelCodigo";
            this.panelCodigo.Size = new System.Drawing.Size(198, 59);
            this.panelCodigo.TabIndex = 28;
            // 
            // comboBox_Categorias
            // 
            this.comboBox_Categorias.FormattingEnabled = true;
            this.comboBox_Categorias.Location = new System.Drawing.Point(6, 263);
            this.comboBox_Categorias.Name = "comboBox_Categorias";
            this.comboBox_Categorias.Size = new System.Drawing.Size(198, 21);
            this.comboBox_Categorias.TabIndex = 27;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.Color.Green;
            this.label15.Location = new System.Drawing.Point(6, 246);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(57, 13);
            this.label15.TabIndex = 26;
            this.label15.Text = "Categorias";
            // 
            // comboBox_DepartamentoPDT
            // 
            this.comboBox_DepartamentoPDT.FormattingEnabled = true;
            this.comboBox_DepartamentoPDT.Location = new System.Drawing.Point(6, 222);
            this.comboBox_DepartamentoPDT.Name = "comboBox_DepartamentoPDT";
            this.comboBox_DepartamentoPDT.Size = new System.Drawing.Size(198, 21);
            this.comboBox_DepartamentoPDT.TabIndex = 25;
            // 
            // label_DepartamentoPDT
            // 
            this.label_DepartamentoPDT.AutoSize = true;
            this.label_DepartamentoPDT.ForeColor = System.Drawing.Color.Green;
            this.label_DepartamentoPDT.Location = new System.Drawing.Point(6, 205);
            this.label_DepartamentoPDT.Name = "label_DepartamentoPDT";
            this.label_DepartamentoPDT.Size = new System.Drawing.Size(79, 13);
            this.label_DepartamentoPDT.TabIndex = 24;
            this.label_DepartamentoPDT.Text = "Departamentos";
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(107, 350);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(84, 39);
            this.button1.TabIndex = 17;
            this.button1.Text = "Eliminar";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // textBox_DescripcionPDT
            // 
            this.textBox_DescripcionPDT.Location = new System.Drawing.Point(6, 141);
            this.textBox_DescripcionPDT.Name = "textBox_DescripcionPDT";
            this.textBox_DescripcionPDT.Size = new System.Drawing.Size(198, 20);
            this.textBox_DescripcionPDT.TabIndex = 16;
            // 
            // label_DescripcionPDT
            // 
            this.label_DescripcionPDT.AutoSize = true;
            this.label_DescripcionPDT.Location = new System.Drawing.Point(6, 125);
            this.label_DescripcionPDT.Name = "label_DescripcionPDT";
            this.label_DescripcionPDT.Size = new System.Drawing.Size(63, 13);
            this.label_DescripcionPDT.TabIndex = 15;
            this.label_DescripcionPDT.Text = "Descripción";
            // 
            // button_CancelarPDT
            // 
            this.button_CancelarPDT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_CancelarPDT.Image = ((System.Drawing.Image)(resources.GetObject("button_CancelarPDT.Image")));
            this.button_CancelarPDT.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_CancelarPDT.Location = new System.Drawing.Point(197, 350);
            this.button_CancelarPDT.Name = "button_CancelarPDT";
            this.button_CancelarPDT.Size = new System.Drawing.Size(84, 39);
            this.button_CancelarPDT.TabIndex = 14;
            this.button_CancelarPDT.Text = "Cancelar";
            this.button_CancelarPDT.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_CancelarPDT.UseVisualStyleBackColor = true;
            // 
            // button_GuardarPDT
            // 
            this.button_GuardarPDT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_GuardarPDT.Image = ((System.Drawing.Image)(resources.GetObject("button_GuardarPDT.Image")));
            this.button_GuardarPDT.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_GuardarPDT.Location = new System.Drawing.Point(17, 350);
            this.button_GuardarPDT.Name = "button_GuardarPDT";
            this.button_GuardarPDT.Size = new System.Drawing.Size(84, 39);
            this.button_GuardarPDT.TabIndex = 13;
            this.button_GuardarPDT.Text = "Guardar ";
            this.button_GuardarPDT.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_GuardarPDT.UseVisualStyleBackColor = true;
            // 
            // textBox_PrecioVentaPDT
            // 
            this.textBox_PrecioVentaPDT.Location = new System.Drawing.Point(6, 180);
            this.textBox_PrecioVentaPDT.Name = "textBox_PrecioVentaPDT";
            this.textBox_PrecioVentaPDT.Size = new System.Drawing.Size(198, 20);
            this.textBox_PrecioVentaPDT.TabIndex = 6;
            // 
            // label_PrecioVentaPDT
            // 
            this.label_PrecioVentaPDT.AutoSize = true;
            this.label_PrecioVentaPDT.Location = new System.Drawing.Point(6, 164);
            this.label_PrecioVentaPDT.Name = "label_PrecioVentaPDT";
            this.label_PrecioVentaPDT.Size = new System.Drawing.Size(67, 13);
            this.label_PrecioVentaPDT.TabIndex = 5;
            this.label_PrecioVentaPDT.Text = "Precio venta";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Sienna;
            this.label19.Location = new System.Drawing.Point(6, 29);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(246, 16);
            this.label19.TabIndex = 0;
            this.label19.Text = "Llene la información del nuevo Producto";
            // 
            // groupBox5
            // 
            this.groupBox5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox5.Controls.Add(this.label45);
            this.groupBox5.Controls.Add(this.textBox_CoprasProductos);
            this.groupBox5.Controls.Add(this.label30);
            this.groupBox5.Controls.Add(this.label14);
            this.groupBox5.ForeColor = System.Drawing.Color.Green;
            this.groupBox5.Location = new System.Drawing.Point(6, 6);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(1025, 52);
            this.groupBox5.TabIndex = 3;
            this.groupBox5.TabStop = false;
            // 
            // label45
            // 
            this.label45.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.Sienna;
            this.label45.Location = new System.Drawing.Point(697, 33);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(160, 16);
            this.label45.TabIndex = 14;
            this.label45.Text = "Productos comprados";
            // 
            // textBox_CoprasProductos
            // 
            this.textBox_CoprasProductos.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox_CoprasProductos.Location = new System.Drawing.Point(368, 18);
            this.textBox_CoprasProductos.Multiline = true;
            this.textBox_CoprasProductos.Name = "textBox_CoprasProductos";
            this.textBox_CoprasProductos.Size = new System.Drawing.Size(198, 25);
            this.textBox_CoprasProductos.TabIndex = 13;
            // 
            // label30
            // 
            this.label30.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.Sienna;
            this.label30.Location = new System.Drawing.Point(306, 20);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(56, 16);
            this.label30.TabIndex = 12;
            this.label30.Text = "Buscar";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Sienna;
            this.label14.Location = new System.Drawing.Point(3, 12);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(146, 31);
            this.label14.TabIndex = 0;
            this.label14.Text = "Productos";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.label29);
            this.tabPage4.Controls.Add(this.groupBox11);
            this.tabPage4.Controls.Add(this.groupBox9);
            this.tabPage4.Controls.Add(this.groupBox8);
            this.tabPage4.Location = new System.Drawing.Point(4, 4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1037, 531);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "tabPage4";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // label29
            // 
            this.label29.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.SteelBlue;
            this.label29.Location = new System.Drawing.Point(495, 503);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(60, 16);
            this.label29.TabIndex = 17;
            this.label29.Text = "©PDHN";
            // 
            // groupBox11
            // 
            this.groupBox11.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox11.Controls.Add(this.dataGridView_Cat);
            this.groupBox11.Controls.Add(this.dataGridView_Dpto);
            this.groupBox11.Location = new System.Drawing.Point(315, 64);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(716, 392);
            this.groupBox11.TabIndex = 6;
            this.groupBox11.TabStop = false;
            // 
            // dataGridView_Cat
            // 
            this.dataGridView_Cat.AllowUserToAddRows = false;
            this.dataGridView_Cat.AllowUserToDeleteRows = false;
            this.dataGridView_Cat.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView_Cat.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_Cat.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_Cat.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridView_Cat.ColumnHeadersHeight = 25;
            this.dataGridView_Cat.Location = new System.Drawing.Point(514, 19);
            this.dataGridView_Cat.Name = "dataGridView_Cat";
            this.dataGridView_Cat.ReadOnly = true;
            this.dataGridView_Cat.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_Cat.Size = new System.Drawing.Size(196, 302);
            this.dataGridView_Cat.TabIndex = 12;
            // 
            // dataGridView_Dpto
            // 
            this.dataGridView_Dpto.AllowUserToAddRows = false;
            this.dataGridView_Dpto.AllowUserToDeleteRows = false;
            this.dataGridView_Dpto.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView_Dpto.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_Dpto.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_Dpto.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridView_Dpto.ColumnHeadersHeight = 25;
            this.dataGridView_Dpto.Location = new System.Drawing.Point(6, 19);
            this.dataGridView_Dpto.Name = "dataGridView_Dpto";
            this.dataGridView_Dpto.ReadOnly = true;
            this.dataGridView_Dpto.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_Dpto.Size = new System.Drawing.Size(196, 302);
            this.dataGridView_Dpto.TabIndex = 0;
            // 
            // groupBox9
            // 
            this.groupBox9.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox9.Controls.Add(this.groupBox12);
            this.groupBox9.Controls.Add(this.groupBox10);
            this.groupBox9.Controls.Add(this.radioButton_Cat);
            this.groupBox9.Controls.Add(this.radioButton_Dpto);
            this.groupBox9.Controls.Add(this.button_EliminarDpto);
            this.groupBox9.Controls.Add(this.button_DptoCancelar);
            this.groupBox9.Controls.Add(this.button_CuardarDpto);
            this.groupBox9.Controls.Add(this.label26);
            this.groupBox9.Location = new System.Drawing.Point(6, 64);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(303, 392);
            this.groupBox9.TabIndex = 5;
            this.groupBox9.TabStop = false;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.label_Cat);
            this.groupBox12.Controls.Add(this.textBox_Cat);
            this.groupBox12.Location = new System.Drawing.Point(9, 183);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(209, 85);
            this.groupBox12.TabIndex = 21;
            this.groupBox12.TabStop = false;
            // 
            // label_Cat
            // 
            this.label_Cat.AutoSize = true;
            this.label_Cat.Location = new System.Drawing.Point(5, 23);
            this.label_Cat.Name = "label_Cat";
            this.label_Cat.Size = new System.Drawing.Size(52, 13);
            this.label_Cat.TabIndex = 3;
            this.label_Cat.Text = "Categoria";
            // 
            // textBox_Cat
            // 
            this.textBox_Cat.Location = new System.Drawing.Point(5, 45);
            this.textBox_Cat.Name = "textBox_Cat";
            this.textBox_Cat.Size = new System.Drawing.Size(198, 20);
            this.textBox_Cat.TabIndex = 4;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.label_Dpto);
            this.groupBox10.Controls.Add(this.textBox_Dpto);
            this.groupBox10.Location = new System.Drawing.Point(9, 92);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(209, 85);
            this.groupBox10.TabIndex = 20;
            this.groupBox10.TabStop = false;
            // 
            // label_Dpto
            // 
            this.label_Dpto.AutoSize = true;
            this.label_Dpto.Location = new System.Drawing.Point(5, 25);
            this.label_Dpto.Name = "label_Dpto";
            this.label_Dpto.Size = new System.Drawing.Size(74, 13);
            this.label_Dpto.TabIndex = 1;
            this.label_Dpto.Text = "Departamento";
            // 
            // textBox_Dpto
            // 
            this.textBox_Dpto.Location = new System.Drawing.Point(5, 41);
            this.textBox_Dpto.Name = "textBox_Dpto";
            this.textBox_Dpto.Size = new System.Drawing.Size(198, 20);
            this.textBox_Dpto.TabIndex = 2;
            // 
            // radioButton_Cat
            // 
            this.radioButton_Cat.AutoSize = true;
            this.radioButton_Cat.Location = new System.Drawing.Point(63, 69);
            this.radioButton_Cat.Name = "radioButton_Cat";
            this.radioButton_Cat.Size = new System.Drawing.Size(41, 17);
            this.radioButton_Cat.TabIndex = 19;
            this.radioButton_Cat.Text = "Cat";
            this.radioButton_Cat.UseVisualStyleBackColor = true;
            // 
            // radioButton_Dpto
            // 
            this.radioButton_Dpto.AutoSize = true;
            this.radioButton_Dpto.Checked = true;
            this.radioButton_Dpto.Location = new System.Drawing.Point(9, 69);
            this.radioButton_Dpto.Name = "radioButton_Dpto";
            this.radioButton_Dpto.Size = new System.Drawing.Size(48, 17);
            this.radioButton_Dpto.TabIndex = 18;
            this.radioButton_Dpto.TabStop = true;
            this.radioButton_Dpto.Text = "Dpto";
            this.radioButton_Dpto.UseVisualStyleBackColor = true;
            // 
            // button_EliminarDpto
            // 
            this.button_EliminarDpto.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_EliminarDpto.Image = ((System.Drawing.Image)(resources.GetObject("button_EliminarDpto.Image")));
            this.button_EliminarDpto.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_EliminarDpto.Location = new System.Drawing.Point(107, 350);
            this.button_EliminarDpto.Name = "button_EliminarDpto";
            this.button_EliminarDpto.Size = new System.Drawing.Size(84, 39);
            this.button_EliminarDpto.TabIndex = 17;
            this.button_EliminarDpto.Text = "Eliminar";
            this.button_EliminarDpto.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_EliminarDpto.UseVisualStyleBackColor = true;
            // 
            // button_DptoCancelar
            // 
            this.button_DptoCancelar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_DptoCancelar.Image = ((System.Drawing.Image)(resources.GetObject("button_DptoCancelar.Image")));
            this.button_DptoCancelar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_DptoCancelar.Location = new System.Drawing.Point(197, 350);
            this.button_DptoCancelar.Name = "button_DptoCancelar";
            this.button_DptoCancelar.Size = new System.Drawing.Size(84, 39);
            this.button_DptoCancelar.TabIndex = 14;
            this.button_DptoCancelar.Text = "Cancelar";
            this.button_DptoCancelar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_DptoCancelar.UseVisualStyleBackColor = true;
            // 
            // button_CuardarDpto
            // 
            this.button_CuardarDpto.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_CuardarDpto.Image = ((System.Drawing.Image)(resources.GetObject("button_CuardarDpto.Image")));
            this.button_CuardarDpto.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_CuardarDpto.Location = new System.Drawing.Point(17, 350);
            this.button_CuardarDpto.Name = "button_CuardarDpto";
            this.button_CuardarDpto.Size = new System.Drawing.Size(84, 39);
            this.button_CuardarDpto.TabIndex = 13;
            this.button_CuardarDpto.Text = "Guardar ";
            this.button_CuardarDpto.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_CuardarDpto.UseVisualStyleBackColor = true;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.SteelBlue;
            this.label26.Location = new System.Drawing.Point(6, 29);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(194, 16);
            this.label26.TabIndex = 0;
            this.label26.Text = "Ingrese el nuevo departamento";
            // 
            // groupBox8
            // 
            this.groupBox8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox8.Controls.Add(this.textBox_BuscarDpto);
            this.groupBox8.Controls.Add(this.label16);
            this.groupBox8.Controls.Add(this.label17);
            this.groupBox8.ForeColor = System.Drawing.Color.Green;
            this.groupBox8.Location = new System.Drawing.Point(6, 6);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(1025, 52);
            this.groupBox8.TabIndex = 4;
            this.groupBox8.TabStop = false;
            // 
            // textBox_BuscarDpto
            // 
            this.textBox_BuscarDpto.Location = new System.Drawing.Point(368, 18);
            this.textBox_BuscarDpto.Multiline = true;
            this.textBox_BuscarDpto.Name = "textBox_BuscarDpto";
            this.textBox_BuscarDpto.Size = new System.Drawing.Size(198, 25);
            this.textBox_BuscarDpto.TabIndex = 11;
            // 
            // label16
            // 
            this.label16.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.SteelBlue;
            this.label16.Location = new System.Drawing.Point(306, 20);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(56, 16);
            this.label16.TabIndex = 10;
            this.label16.Text = "Buscar";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.SteelBlue;
            this.label17.Location = new System.Drawing.Point(3, 12);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(186, 31);
            this.label17.TabIndex = 0;
            this.label17.Text = "Dpto and Cat";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.label58);
            this.tabPage5.Controls.Add(this.groupBox15);
            this.tabPage5.Controls.Add(this.groupBox14);
            this.tabPage5.Controls.Add(this.groupBox13);
            this.tabPage5.Location = new System.Drawing.Point(4, 4);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1037, 531);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "tabPage5";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // label58
            // 
            this.label58.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.ForeColor = System.Drawing.Color.LightSlateGray;
            this.label58.Location = new System.Drawing.Point(495, 503);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(60, 16);
            this.label58.TabIndex = 18;
            this.label58.Text = "©PDHN";
            // 
            // groupBox15
            // 
            this.groupBox15.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox15.Controls.Add(this.label_PaginasCompras);
            this.groupBox15.Controls.Add(this.button_UltimaCompra);
            this.groupBox15.Controls.Add(this.button_AnteriorCompra);
            this.groupBox15.Controls.Add(this.button_SiguienteCompra);
            this.groupBox15.Controls.Add(this.button_PrimerCompra);
            this.groupBox15.Controls.Add(this.dataGridView_ComprasProductos);
            this.groupBox15.Location = new System.Drawing.Point(315, 64);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(716, 397);
            this.groupBox15.TabIndex = 6;
            this.groupBox15.TabStop = false;
            // 
            // label_PaginasCompras
            // 
            this.label_PaginasCompras.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label_PaginasCompras.AutoSize = true;
            this.label_PaginasCompras.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_PaginasCompras.ForeColor = System.Drawing.Color.LightSlateGray;
            this.label_PaginasCompras.Location = new System.Drawing.Point(314, 339);
            this.label_PaginasCompras.Name = "label_PaginasCompras";
            this.label_PaginasCompras.Size = new System.Drawing.Size(65, 16);
            this.label_PaginasCompras.TabIndex = 9;
            this.label_PaginasCompras.Text = "Paginas";
            // 
            // button_UltimaCompra
            // 
            this.button_UltimaCompra.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.button_UltimaCompra.Image = ((System.Drawing.Image)(resources.GetObject("button_UltimaCompra.Image")));
            this.button_UltimaCompra.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_UltimaCompra.Location = new System.Drawing.Point(421, 360);
            this.button_UltimaCompra.Name = "button_UltimaCompra";
            this.button_UltimaCompra.Size = new System.Drawing.Size(75, 29);
            this.button_UltimaCompra.TabIndex = 8;
            this.button_UltimaCompra.Text = "Ultimo";
            this.button_UltimaCompra.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_UltimaCompra.UseVisualStyleBackColor = true;
            // 
            // button_AnteriorCompra
            // 
            this.button_AnteriorCompra.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.button_AnteriorCompra.Image = ((System.Drawing.Image)(resources.GetObject("button_AnteriorCompra.Image")));
            this.button_AnteriorCompra.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_AnteriorCompra.Location = new System.Drawing.Point(259, 360);
            this.button_AnteriorCompra.Name = "button_AnteriorCompra";
            this.button_AnteriorCompra.Size = new System.Drawing.Size(75, 29);
            this.button_AnteriorCompra.TabIndex = 7;
            this.button_AnteriorCompra.Text = "Anterior";
            this.button_AnteriorCompra.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_AnteriorCompra.UseVisualStyleBackColor = true;
            // 
            // button_SiguienteCompra
            // 
            this.button_SiguienteCompra.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.button_SiguienteCompra.Image = ((System.Drawing.Image)(resources.GetObject("button_SiguienteCompra.Image")));
            this.button_SiguienteCompra.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_SiguienteCompra.Location = new System.Drawing.Point(340, 360);
            this.button_SiguienteCompra.Name = "button_SiguienteCompra";
            this.button_SiguienteCompra.Size = new System.Drawing.Size(75, 29);
            this.button_SiguienteCompra.TabIndex = 6;
            this.button_SiguienteCompra.Text = "Siguient";
            this.button_SiguienteCompra.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_SiguienteCompra.UseVisualStyleBackColor = true;
            // 
            // button_PrimerCompra
            // 
            this.button_PrimerCompra.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.button_PrimerCompra.Image = ((System.Drawing.Image)(resources.GetObject("button_PrimerCompra.Image")));
            this.button_PrimerCompra.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_PrimerCompra.Location = new System.Drawing.Point(178, 360);
            this.button_PrimerCompra.Name = "button_PrimerCompra";
            this.button_PrimerCompra.Size = new System.Drawing.Size(75, 29);
            this.button_PrimerCompra.TabIndex = 5;
            this.button_PrimerCompra.Text = "Primero";
            this.button_PrimerCompra.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_PrimerCompra.UseVisualStyleBackColor = true;
            // 
            // dataGridView_ComprasProductos
            // 
            this.dataGridView_ComprasProductos.AllowUserToAddRows = false;
            this.dataGridView_ComprasProductos.AllowUserToDeleteRows = false;
            this.dataGridView_ComprasProductos.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView_ComprasProductos.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_ComprasProductos.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_ComprasProductos.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dataGridView_ComprasProductos.ColumnHeadersHeight = 25;
            this.dataGridView_ComprasProductos.Location = new System.Drawing.Point(6, 19);
            this.dataGridView_ComprasProductos.Name = "dataGridView_ComprasProductos";
            this.dataGridView_ComprasProductos.ReadOnly = true;
            this.dataGridView_ComprasProductos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_ComprasProductos.Size = new System.Drawing.Size(704, 307);
            this.dataGridView_ComprasProductos.TabIndex = 0;
            // 
            // groupBox14
            // 
            this.groupBox14.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox14.Controls.Add(this.label_ImprorteCompras);
            this.groupBox14.Controls.Add(this.label_ImportCompra);
            this.groupBox14.Controls.Add(this.textBox_PrecioCompra);
            this.groupBox14.Controls.Add(this.label_PrecioCmpra);
            this.groupBox14.Controls.Add(this.button_EliminarCompras);
            this.groupBox14.Controls.Add(this.textBox_DescpCompra);
            this.groupBox14.Controls.Add(this.label_DescpCompra);
            this.groupBox14.Controls.Add(this.button_CancelarCompras);
            this.groupBox14.Controls.Add(this.button_GuardarCompras);
            this.groupBox14.Controls.Add(this.textBox_CantidadCompra);
            this.groupBox14.Controls.Add(this.label_CantidadCompra);
            this.groupBox14.Controls.Add(this.label28);
            this.groupBox14.Location = new System.Drawing.Point(6, 64);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(303, 397);
            this.groupBox14.TabIndex = 5;
            this.groupBox14.TabStop = false;
            // 
            // label_ImprorteCompras
            // 
            this.label_ImprorteCompras.AutoSize = true;
            this.label_ImprorteCompras.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ImprorteCompras.ForeColor = System.Drawing.Color.LightSlateGray;
            this.label_ImprorteCompras.Location = new System.Drawing.Point(6, 198);
            this.label_ImprorteCompras.Name = "label_ImprorteCompras";
            this.label_ImprorteCompras.Size = new System.Drawing.Size(102, 39);
            this.label_ImprorteCompras.TabIndex = 29;
            this.label_ImprorteCompras.Text = "$0.00";
            // 
            // label_ImportCompra
            // 
            this.label_ImportCompra.AutoSize = true;
            this.label_ImportCompra.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ImportCompra.ForeColor = System.Drawing.Color.Black;
            this.label_ImportCompra.Location = new System.Drawing.Point(6, 176);
            this.label_ImportCompra.Name = "label_ImportCompra";
            this.label_ImportCompra.Size = new System.Drawing.Size(55, 17);
            this.label_ImportCompra.TabIndex = 28;
            this.label_ImportCompra.Text = "Importe";
            // 
            // textBox_PrecioCompra
            // 
            this.textBox_PrecioCompra.Location = new System.Drawing.Point(6, 153);
            this.textBox_PrecioCompra.Name = "textBox_PrecioCompra";
            this.textBox_PrecioCompra.Size = new System.Drawing.Size(198, 20);
            this.textBox_PrecioCompra.TabIndex = 23;
            // 
            // label_PrecioCmpra
            // 
            this.label_PrecioCmpra.AutoSize = true;
            this.label_PrecioCmpra.Location = new System.Drawing.Point(6, 137);
            this.label_PrecioCmpra.Name = "label_PrecioCmpra";
            this.label_PrecioCmpra.Size = new System.Drawing.Size(75, 13);
            this.label_PrecioCmpra.TabIndex = 22;
            this.label_PrecioCmpra.Text = "Precio compra";
            // 
            // button_EliminarCompras
            // 
            this.button_EliminarCompras.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_EliminarCompras.Image = ((System.Drawing.Image)(resources.GetObject("button_EliminarCompras.Image")));
            this.button_EliminarCompras.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_EliminarCompras.Location = new System.Drawing.Point(107, 350);
            this.button_EliminarCompras.Name = "button_EliminarCompras";
            this.button_EliminarCompras.Size = new System.Drawing.Size(84, 39);
            this.button_EliminarCompras.TabIndex = 17;
            this.button_EliminarCompras.Text = "Eliminar";
            this.button_EliminarCompras.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_EliminarCompras.UseVisualStyleBackColor = true;
            // 
            // textBox_DescpCompra
            // 
            this.textBox_DescpCompra.Location = new System.Drawing.Point(6, 74);
            this.textBox_DescpCompra.Name = "textBox_DescpCompra";
            this.textBox_DescpCompra.Size = new System.Drawing.Size(198, 20);
            this.textBox_DescpCompra.TabIndex = 16;
            // 
            // label_DescpCompra
            // 
            this.label_DescpCompra.AutoSize = true;
            this.label_DescpCompra.Location = new System.Drawing.Point(6, 58);
            this.label_DescpCompra.Name = "label_DescpCompra";
            this.label_DescpCompra.Size = new System.Drawing.Size(63, 13);
            this.label_DescpCompra.TabIndex = 15;
            this.label_DescpCompra.Text = "Descripción";
            // 
            // button_CancelarCompras
            // 
            this.button_CancelarCompras.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_CancelarCompras.Image = ((System.Drawing.Image)(resources.GetObject("button_CancelarCompras.Image")));
            this.button_CancelarCompras.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_CancelarCompras.Location = new System.Drawing.Point(197, 350);
            this.button_CancelarCompras.Name = "button_CancelarCompras";
            this.button_CancelarCompras.Size = new System.Drawing.Size(84, 39);
            this.button_CancelarCompras.TabIndex = 14;
            this.button_CancelarCompras.Text = "Cancelar";
            this.button_CancelarCompras.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_CancelarCompras.UseVisualStyleBackColor = true;
            // 
            // button_GuardarCompras
            // 
            this.button_GuardarCompras.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_GuardarCompras.Image = ((System.Drawing.Image)(resources.GetObject("button_GuardarCompras.Image")));
            this.button_GuardarCompras.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_GuardarCompras.Location = new System.Drawing.Point(17, 350);
            this.button_GuardarCompras.Name = "button_GuardarCompras";
            this.button_GuardarCompras.Size = new System.Drawing.Size(84, 39);
            this.button_GuardarCompras.TabIndex = 13;
            this.button_GuardarCompras.Text = "Guardar ";
            this.button_GuardarCompras.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_GuardarCompras.UseVisualStyleBackColor = true;
            // 
            // textBox_CantidadCompra
            // 
            this.textBox_CantidadCompra.Location = new System.Drawing.Point(6, 114);
            this.textBox_CantidadCompra.Name = "textBox_CantidadCompra";
            this.textBox_CantidadCompra.Size = new System.Drawing.Size(198, 20);
            this.textBox_CantidadCompra.TabIndex = 6;
            // 
            // label_CantidadCompra
            // 
            this.label_CantidadCompra.AutoSize = true;
            this.label_CantidadCompra.Location = new System.Drawing.Point(6, 98);
            this.label_CantidadCompra.Name = "label_CantidadCompra";
            this.label_CantidadCompra.Size = new System.Drawing.Size(49, 13);
            this.label_CantidadCompra.TabIndex = 5;
            this.label_CantidadCompra.Text = "Cantidad";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.LightSlateGray;
            this.label28.Location = new System.Drawing.Point(6, 29);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(246, 16);
            this.label28.TabIndex = 0;
            this.label28.Text = "Llene la información del nuevo Producto";
            // 
            // groupBox13
            // 
            this.groupBox13.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox13.Controls.Add(this.textBox_BuscarCompras);
            this.groupBox13.Controls.Add(this.label18);
            this.groupBox13.Controls.Add(this.label20);
            this.groupBox13.ForeColor = System.Drawing.Color.Green;
            this.groupBox13.Location = new System.Drawing.Point(6, 6);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(1025, 52);
            this.groupBox13.TabIndex = 4;
            this.groupBox13.TabStop = false;
            // 
            // textBox_BuscarCompras
            // 
            this.textBox_BuscarCompras.Location = new System.Drawing.Point(368, 18);
            this.textBox_BuscarCompras.Multiline = true;
            this.textBox_BuscarCompras.Name = "textBox_BuscarCompras";
            this.textBox_BuscarCompras.Size = new System.Drawing.Size(198, 25);
            this.textBox_BuscarCompras.TabIndex = 11;
            // 
            // label18
            // 
            this.label18.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.LightSlateGray;
            this.label18.Location = new System.Drawing.Point(306, 20);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(56, 16);
            this.label18.TabIndex = 10;
            this.label18.Text = "Buscar";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.LightSlateGray;
            this.label20.Location = new System.Drawing.Point(3, 12);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(139, 31);
            this.label20.TabIndex = 0;
            this.label20.Text = "Compras ";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.label56);
            this.tabPage6.Controls.Add(this.button_db);
            this.tabPage6.Controls.Add(this.label37);
            this.tabPage6.Controls.Add(this.button_Reporte);
            this.tabPage6.Controls.Add(this.label31);
            this.tabPage6.Controls.Add(this.button_Cageros);
            this.tabPage6.Controls.Add(this.groupBox21);
            this.tabPage6.Location = new System.Drawing.Point(4, 4);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(1037, 531);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "tabPage6";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(139, 130);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(75, 13);
            this.label56.TabIndex = 25;
            this.label56.Text = "Base de datos";
            // 
            // button_db
            // 
            this.button_db.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_db.Image = ((System.Drawing.Image)(resources.GetObject("button_db.Image")));
            this.button_db.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_db.Location = new System.Drawing.Point(159, 88);
            this.button_db.Name = "button_db";
            this.button_db.Size = new System.Drawing.Size(33, 39);
            this.button_db.TabIndex = 24;
            this.button_db.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_db.UseVisualStyleBackColor = true;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(78, 130);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(50, 13);
            this.label37.TabIndex = 23;
            this.label37.Text = "Reportes";
            // 
            // button_Reporte
            // 
            this.button_Reporte.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Reporte.Image = ((System.Drawing.Image)(resources.GetObject("button_Reporte.Image")));
            this.button_Reporte.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Reporte.Location = new System.Drawing.Point(87, 88);
            this.button_Reporte.Name = "button_Reporte";
            this.button_Reporte.Size = new System.Drawing.Size(33, 39);
            this.button_Reporte.TabIndex = 22;
            this.button_Reporte.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_Reporte.UseVisualStyleBackColor = true;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(12, 130);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(42, 13);
            this.label31.TabIndex = 21;
            this.label31.Text = "Cajeros";
            // 
            // button_Cageros
            // 
            this.button_Cageros.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Cageros.Image = ((System.Drawing.Image)(resources.GetObject("button_Cageros.Image")));
            this.button_Cageros.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Cageros.Location = new System.Drawing.Point(15, 88);
            this.button_Cageros.Name = "button_Cageros";
            this.button_Cageros.Size = new System.Drawing.Size(33, 39);
            this.button_Cageros.TabIndex = 20;
            this.button_Cageros.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_Cageros.UseVisualStyleBackColor = true;
            // 
            // groupBox21
            // 
            this.groupBox21.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox21.Controls.Add(this.label34);
            this.groupBox21.ForeColor = System.Drawing.Color.Green;
            this.groupBox21.Location = new System.Drawing.Point(6, 6);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Size = new System.Drawing.Size(1025, 52);
            this.groupBox21.TabIndex = 5;
            this.groupBox21.TabStop = false;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.SteelBlue;
            this.label34.Location = new System.Drawing.Point(3, 12);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(145, 31);
            this.label34.TabIndex = 0;
            this.label34.Text = "Opciones ";
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.groupBox24);
            this.tabPage7.Controls.Add(this.groupBox23);
            this.tabPage7.Controls.Add(this.groupBox22);
            this.tabPage7.Location = new System.Drawing.Point(4, 4);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(1037, 531);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "tabPage7";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // groupBox24
            // 
            this.groupBox24.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox24.Controls.Add(this.dataGridView_Usuarios);
            this.groupBox24.Location = new System.Drawing.Point(315, 64);
            this.groupBox24.Name = "groupBox24";
            this.groupBox24.Size = new System.Drawing.Size(716, 409);
            this.groupBox24.TabIndex = 5;
            this.groupBox24.TabStop = false;
            // 
            // dataGridView_Usuarios
            // 
            this.dataGridView_Usuarios.AllowUserToAddRows = false;
            this.dataGridView_Usuarios.AllowUserToDeleteRows = false;
            this.dataGridView_Usuarios.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView_Usuarios.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_Usuarios.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_Usuarios.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.dataGridView_Usuarios.ColumnHeadersHeight = 25;
            this.dataGridView_Usuarios.Location = new System.Drawing.Point(6, 19);
            this.dataGridView_Usuarios.Name = "dataGridView_Usuarios";
            this.dataGridView_Usuarios.ReadOnly = true;
            this.dataGridView_Usuarios.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_Usuarios.Size = new System.Drawing.Size(704, 319);
            this.dataGridView_Usuarios.TabIndex = 0;
            // 
            // groupBox23
            // 
            this.groupBox23.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox23.Controls.Add(this.radioButton_Cajero);
            this.groupBox23.Controls.Add(this.radioButton_Admin);
            this.groupBox23.Controls.Add(this.label_Contraseña);
            this.groupBox23.Controls.Add(this.textBox_Contraseña);
            this.groupBox23.Controls.Add(this.label_User);
            this.groupBox23.Controls.Add(this.textBox_Usuario);
            this.groupBox23.Controls.Add(this.button_EliminarUsuario);
            this.groupBox23.Controls.Add(this.textBox_ApellidoUser);
            this.groupBox23.Controls.Add(this.label_ApellidoUser);
            this.groupBox23.Controls.Add(this.button_CancelarUser);
            this.groupBox23.Controls.Add(this.button_GuardarUser);
            this.groupBox23.Controls.Add(this.textBox_TelefonoUser);
            this.groupBox23.Controls.Add(this.label_TelefonoUser);
            this.groupBox23.Controls.Add(this.textBox_NombreUser);
            this.groupBox23.Controls.Add(this.label_NombreUser);
            this.groupBox23.Controls.Add(this.label55);
            this.groupBox23.Location = new System.Drawing.Point(6, 64);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Size = new System.Drawing.Size(303, 409);
            this.groupBox23.TabIndex = 4;
            this.groupBox23.TabStop = false;
            // 
            // radioButton_Cajero
            // 
            this.radioButton_Cajero.AutoSize = true;
            this.radioButton_Cajero.Location = new System.Drawing.Point(84, 190);
            this.radioButton_Cajero.Name = "radioButton_Cajero";
            this.radioButton_Cajero.Size = new System.Drawing.Size(55, 17);
            this.radioButton_Cajero.TabIndex = 27;
            this.radioButton_Cajero.TabStop = true;
            this.radioButton_Cajero.Text = "Cajero";
            this.radioButton_Cajero.UseVisualStyleBackColor = true;
            // 
            // radioButton_Admin
            // 
            this.radioButton_Admin.AutoSize = true;
            this.radioButton_Admin.Location = new System.Drawing.Point(8, 189);
            this.radioButton_Admin.Name = "radioButton_Admin";
            this.radioButton_Admin.Size = new System.Drawing.Size(57, 17);
            this.radioButton_Admin.TabIndex = 26;
            this.radioButton_Admin.TabStop = true;
            this.radioButton_Admin.Text = "Admin.";
            this.radioButton_Admin.UseVisualStyleBackColor = true;
            // 
            // label_Contraseña
            // 
            this.label_Contraseña.AutoSize = true;
            this.label_Contraseña.Location = new System.Drawing.Point(5, 261);
            this.label_Contraseña.Name = "label_Contraseña";
            this.label_Contraseña.Size = new System.Drawing.Size(61, 13);
            this.label_Contraseña.TabIndex = 25;
            this.label_Contraseña.Text = "Contraseña";
            // 
            // textBox_Contraseña
            // 
            this.textBox_Contraseña.Location = new System.Drawing.Point(6, 277);
            this.textBox_Contraseña.Name = "textBox_Contraseña";
            this.textBox_Contraseña.Size = new System.Drawing.Size(198, 20);
            this.textBox_Contraseña.TabIndex = 24;
            // 
            // label_User
            // 
            this.label_User.AutoSize = true;
            this.label_User.Location = new System.Drawing.Point(5, 221);
            this.label_User.Name = "label_User";
            this.label_User.Size = new System.Drawing.Size(43, 13);
            this.label_User.TabIndex = 23;
            this.label_User.Text = "Usuario";
            // 
            // textBox_Usuario
            // 
            this.textBox_Usuario.Location = new System.Drawing.Point(6, 237);
            this.textBox_Usuario.Name = "textBox_Usuario";
            this.textBox_Usuario.Size = new System.Drawing.Size(198, 20);
            this.textBox_Usuario.TabIndex = 22;
            // 
            // button_EliminarUsuario
            // 
            this.button_EliminarUsuario.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_EliminarUsuario.Image = ((System.Drawing.Image)(resources.GetObject("button_EliminarUsuario.Image")));
            this.button_EliminarUsuario.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_EliminarUsuario.Location = new System.Drawing.Point(107, 350);
            this.button_EliminarUsuario.Name = "button_EliminarUsuario";
            this.button_EliminarUsuario.Size = new System.Drawing.Size(84, 39);
            this.button_EliminarUsuario.TabIndex = 17;
            this.button_EliminarUsuario.Text = "Eliminar";
            this.button_EliminarUsuario.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_EliminarUsuario.UseVisualStyleBackColor = true;
            // 
            // textBox_ApellidoUser
            // 
            this.textBox_ApellidoUser.Location = new System.Drawing.Point(6, 111);
            this.textBox_ApellidoUser.Name = "textBox_ApellidoUser";
            this.textBox_ApellidoUser.Size = new System.Drawing.Size(198, 20);
            this.textBox_ApellidoUser.TabIndex = 16;
            // 
            // label_ApellidoUser
            // 
            this.label_ApellidoUser.AutoSize = true;
            this.label_ApellidoUser.Location = new System.Drawing.Point(6, 95);
            this.label_ApellidoUser.Name = "label_ApellidoUser";
            this.label_ApellidoUser.Size = new System.Drawing.Size(44, 13);
            this.label_ApellidoUser.TabIndex = 15;
            this.label_ApellidoUser.Text = "Apellido";
            // 
            // button_CancelarUser
            // 
            this.button_CancelarUser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_CancelarUser.Image = ((System.Drawing.Image)(resources.GetObject("button_CancelarUser.Image")));
            this.button_CancelarUser.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_CancelarUser.Location = new System.Drawing.Point(197, 350);
            this.button_CancelarUser.Name = "button_CancelarUser";
            this.button_CancelarUser.Size = new System.Drawing.Size(84, 39);
            this.button_CancelarUser.TabIndex = 14;
            this.button_CancelarUser.Text = "Cancelar";
            this.button_CancelarUser.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_CancelarUser.UseVisualStyleBackColor = true;
            // 
            // button_GuardarUser
            // 
            this.button_GuardarUser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_GuardarUser.Image = ((System.Drawing.Image)(resources.GetObject("button_GuardarUser.Image")));
            this.button_GuardarUser.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_GuardarUser.Location = new System.Drawing.Point(17, 350);
            this.button_GuardarUser.Name = "button_GuardarUser";
            this.button_GuardarUser.Size = new System.Drawing.Size(84, 39);
            this.button_GuardarUser.TabIndex = 13;
            this.button_GuardarUser.Text = "Guardar ";
            this.button_GuardarUser.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_GuardarUser.UseVisualStyleBackColor = true;
            // 
            // textBox_TelefonoUser
            // 
            this.textBox_TelefonoUser.Location = new System.Drawing.Point(6, 152);
            this.textBox_TelefonoUser.Name = "textBox_TelefonoUser";
            this.textBox_TelefonoUser.Size = new System.Drawing.Size(198, 20);
            this.textBox_TelefonoUser.TabIndex = 4;
            // 
            // label_TelefonoUser
            // 
            this.label_TelefonoUser.AutoSize = true;
            this.label_TelefonoUser.Location = new System.Drawing.Point(6, 136);
            this.label_TelefonoUser.Name = "label_TelefonoUser";
            this.label_TelefonoUser.Size = new System.Drawing.Size(49, 13);
            this.label_TelefonoUser.TabIndex = 3;
            this.label_TelefonoUser.Text = "Telefono";
            // 
            // textBox_NombreUser
            // 
            this.textBox_NombreUser.Location = new System.Drawing.Point(6, 71);
            this.textBox_NombreUser.Name = "textBox_NombreUser";
            this.textBox_NombreUser.Size = new System.Drawing.Size(198, 20);
            this.textBox_NombreUser.TabIndex = 2;
            // 
            // label_NombreUser
            // 
            this.label_NombreUser.AutoSize = true;
            this.label_NombreUser.Location = new System.Drawing.Point(6, 55);
            this.label_NombreUser.Name = "label_NombreUser";
            this.label_NombreUser.Size = new System.Drawing.Size(91, 13);
            this.label_NombreUser.TabIndex = 1;
            this.label_NombreUser.Text = "Nombre Completo";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.ForeColor = System.Drawing.Color.Gray;
            this.label55.Location = new System.Drawing.Point(6, 29);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(272, 16);
            this.label55.TabIndex = 0;
            this.label55.Text = "Llene la información del  Cajero o del Admin.";
            // 
            // groupBox22
            // 
            this.groupBox22.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox22.Controls.Add(this.textBox1);
            this.groupBox22.Controls.Add(this.label35);
            this.groupBox22.Controls.Add(this.label36);
            this.groupBox22.ForeColor = System.Drawing.Color.Green;
            this.groupBox22.Location = new System.Drawing.Point(6, 6);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Size = new System.Drawing.Size(1025, 52);
            this.groupBox22.TabIndex = 3;
            this.groupBox22.TabStop = false;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(368, 18);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(198, 25);
            this.textBox1.TabIndex = 11;
            // 
            // label35
            // 
            this.label35.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.DarkGray;
            this.label35.Location = new System.Drawing.Point(306, 20);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(56, 16);
            this.label35.TabIndex = 10;
            this.label35.Text = "Buscar";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.Color.DarkGray;
            this.label36.Location = new System.Drawing.Point(3, 12);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(115, 31);
            this.label36.TabIndex = 0;
            this.label36.Text = "Cajeros";
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.label54);
            this.tabPage8.Controls.Add(this.label53);
            this.tabPage8.Controls.Add(this.label52);
            this.tabPage8.Controls.Add(this.groupBox26);
            this.tabPage8.Controls.Add(this.groupBox27);
            this.tabPage8.Controls.Add(this.groupBox25);
            this.tabPage8.Location = new System.Drawing.Point(4, 4);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Size = new System.Drawing.Size(1037, 531);
            this.tabPage8.TabIndex = 7;
            this.tabPage8.Text = "tabPage8";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // label54
            // 
            this.label54.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.ForeColor = System.Drawing.Color.RosyBrown;
            this.label54.Location = new System.Drawing.Point(809, 406);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(222, 16);
            this.label54.TabIndex = 13;
            this.label54.Text = "Precio de compra del producto";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.ForeColor = System.Drawing.Color.RosyBrown;
            this.label53.Location = new System.Drawing.Point(507, 406);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(208, 16);
            this.label53.TabIndex = 12;
            this.label53.Text = "Precio de venta del producto";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.ForeColor = System.Drawing.Color.RosyBrown;
            this.label52.Location = new System.Drawing.Point(108, 406);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(234, 16);
            this.label52.TabIndex = 11;
            this.label52.Text = "Reporte del producto en bodega";
            // 
            // groupBox26
            // 
            this.groupBox26.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox26.Controls.Add(this.dataGridView_ProductoCompra);
            this.groupBox26.Controls.Add(this.dataGridView_ProductoPrecio);
            this.groupBox26.Controls.Add(this.dataGridView_BodegaReporte);
            this.groupBox26.Location = new System.Drawing.Point(6, 430);
            this.groupBox26.Name = "groupBox26";
            this.groupBox26.Size = new System.Drawing.Size(1025, 103);
            this.groupBox26.TabIndex = 8;
            this.groupBox26.TabStop = false;
            // 
            // dataGridView_ProductoCompra
            // 
            this.dataGridView_ProductoCompra.AllowUserToAddRows = false;
            this.dataGridView_ProductoCompra.AllowUserToDeleteRows = false;
            this.dataGridView_ProductoCompra.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView_ProductoCompra.BackgroundColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_ProductoCompra.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.dataGridView_ProductoCompra.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_ProductoCompra.DefaultCellStyle = dataGridViewCellStyle12;
            this.dataGridView_ProductoCompra.Location = new System.Drawing.Point(766, 19);
            this.dataGridView_ProductoCompra.Name = "dataGridView_ProductoCompra";
            this.dataGridView_ProductoCompra.ReadOnly = true;
            this.dataGridView_ProductoCompra.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_ProductoCompra.Size = new System.Drawing.Size(253, 78);
            this.dataGridView_ProductoCompra.TabIndex = 3;
            // 
            // dataGridView_ProductoPrecio
            // 
            this.dataGridView_ProductoPrecio.AllowUserToAddRows = false;
            this.dataGridView_ProductoPrecio.AllowUserToDeleteRows = false;
            this.dataGridView_ProductoPrecio.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.dataGridView_ProductoPrecio.BackgroundColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_ProductoPrecio.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridView_ProductoPrecio.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_ProductoPrecio.DefaultCellStyle = dataGridViewCellStyle14;
            this.dataGridView_ProductoPrecio.Location = new System.Drawing.Point(478, 19);
            this.dataGridView_ProductoPrecio.Name = "dataGridView_ProductoPrecio";
            this.dataGridView_ProductoPrecio.ReadOnly = true;
            this.dataGridView_ProductoPrecio.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_ProductoPrecio.Size = new System.Drawing.Size(264, 78);
            this.dataGridView_ProductoPrecio.TabIndex = 2;
            // 
            // dataGridView_BodegaReporte
            // 
            this.dataGridView_BodegaReporte.AllowUserToAddRows = false;
            this.dataGridView_BodegaReporte.AllowUserToDeleteRows = false;
            this.dataGridView_BodegaReporte.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.dataGridView_BodegaReporte.BackgroundColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_BodegaReporte.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.dataGridView_BodegaReporte.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_BodegaReporte.DefaultCellStyle = dataGridViewCellStyle16;
            this.dataGridView_BodegaReporte.Location = new System.Drawing.Point(6, 19);
            this.dataGridView_BodegaReporte.Name = "dataGridView_BodegaReporte";
            this.dataGridView_BodegaReporte.ReadOnly = true;
            this.dataGridView_BodegaReporte.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_BodegaReporte.Size = new System.Drawing.Size(453, 78);
            this.dataGridView_BodegaReporte.TabIndex = 1;
            // 
            // groupBox27
            // 
            this.groupBox27.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox27.Controls.Add(this.dataGridView_Reporte);
            this.groupBox27.Controls.Add(this.dataGridView_CatProductos);
            this.groupBox27.Location = new System.Drawing.Point(6, 64);
            this.groupBox27.Name = "groupBox27";
            this.groupBox27.Size = new System.Drawing.Size(1025, 339);
            this.groupBox27.TabIndex = 7;
            this.groupBox27.TabStop = false;
            // 
            // dataGridView_Reporte
            // 
            this.dataGridView_Reporte.AllowUserToAddRows = false;
            this.dataGridView_Reporte.AllowUserToDeleteRows = false;
            this.dataGridView_Reporte.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView_Reporte.BackgroundColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_Reporte.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle17;
            this.dataGridView_Reporte.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Reporte.Location = new System.Drawing.Point(313, 19);
            this.dataGridView_Reporte.Name = "dataGridView_Reporte";
            this.dataGridView_Reporte.ReadOnly = true;
            this.dataGridView_Reporte.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_Reporte.Size = new System.Drawing.Size(57, 300);
            this.dataGridView_Reporte.TabIndex = 1;
            // 
            // dataGridView_CatProductos
            // 
            this.dataGridView_CatProductos.AllowUserToAddRows = false;
            this.dataGridView_CatProductos.AllowUserToDeleteRows = false;
            this.dataGridView_CatProductos.BackgroundColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_CatProductos.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.dataGridView_CatProductos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_CatProductos.Location = new System.Drawing.Point(9, 19);
            this.dataGridView_CatProductos.Name = "dataGridView_CatProductos";
            this.dataGridView_CatProductos.ReadOnly = true;
            this.dataGridView_CatProductos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_CatProductos.Size = new System.Drawing.Size(298, 300);
            this.dataGridView_CatProductos.TabIndex = 0;
            // 
            // groupBox25
            // 
            this.groupBox25.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox25.Controls.Add(this.comboBox_Opciones);
            this.groupBox25.Controls.Add(this.textBox2);
            this.groupBox25.Controls.Add(this.label50);
            this.groupBox25.Controls.Add(this.label51);
            this.groupBox25.ForeColor = System.Drawing.Color.Green;
            this.groupBox25.Location = new System.Drawing.Point(6, 6);
            this.groupBox25.Name = "groupBox25";
            this.groupBox25.Size = new System.Drawing.Size(1025, 52);
            this.groupBox25.TabIndex = 5;
            this.groupBox25.TabStop = false;
            // 
            // comboBox_Opciones
            // 
            this.comboBox_Opciones.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_Opciones.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_Opciones.ForeColor = System.Drawing.Color.RosyBrown;
            this.comboBox_Opciones.FormattingEnabled = true;
            this.comboBox_Opciones.Items.AddRange(new object[] {
            "Compras",
            "Ventas"});
            this.comboBox_Opciones.Location = new System.Drawing.Point(611, 18);
            this.comboBox_Opciones.Name = "comboBox_Opciones";
            this.comboBox_Opciones.Size = new System.Drawing.Size(163, 21);
            this.comboBox_Opciones.TabIndex = 1;
            this.comboBox_Opciones.Text = "Seleccione una opción";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(368, 18);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(198, 25);
            this.textBox2.TabIndex = 11;
            // 
            // label50
            // 
            this.label50.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.ForeColor = System.Drawing.Color.RosyBrown;
            this.label50.Location = new System.Drawing.Point(306, 20);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(56, 16);
            this.label50.TabIndex = 10;
            this.label50.Text = "Buscar";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.ForeColor = System.Drawing.Color.RosyBrown;
            this.label51.Location = new System.Drawing.Point(3, 12);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(139, 31);
            this.label51.TabIndex = 0;
            this.label51.Text = "Compras ";
            // 
            // button_Config
            // 
            this.button_Config.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Config.Image = ((System.Drawing.Image)(resources.GetObject("button_Config.Image")));
            this.button_Config.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Config.Location = new System.Drawing.Point(562, 67);
            this.button_Config.Name = "button_Config";
            this.button_Config.Size = new System.Drawing.Size(105, 39);
            this.button_Config.TabIndex = 33;
            this.button_Config.Text = "Config. ";
            this.button_Config.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_Config.UseVisualStyleBackColor = true;
            // 
            // button_Compras
            // 
            this.button_Compras.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Compras.Image = ((System.Drawing.Image)(resources.GetObject("button_Compras.Image")));
            this.button_Compras.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Compras.Location = new System.Drawing.Point(451, 67);
            this.button_Compras.Name = "button_Compras";
            this.button_Compras.Size = new System.Drawing.Size(105, 39);
            this.button_Compras.TabIndex = 32;
            this.button_Compras.Text = "Compras";
            this.button_Compras.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_Compras.UseVisualStyleBackColor = true;
            // 
            // button_Dpto
            // 
            this.button_Dpto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Dpto.Image = ((System.Drawing.Image)(resources.GetObject("button_Dpto.Image")));
            this.button_Dpto.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Dpto.Location = new System.Drawing.Point(340, 68);
            this.button_Dpto.Name = "button_Dpto";
            this.button_Dpto.Size = new System.Drawing.Size(105, 39);
            this.button_Dpto.TabIndex = 31;
            this.button_Dpto.Text = "Dpto.  Cat.";
            this.button_Dpto.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_Dpto.UseVisualStyleBackColor = true;
            // 
            // button_Productos
            // 
            this.button_Productos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Productos.Image = ((System.Drawing.Image)(resources.GetObject("button_Productos.Image")));
            this.button_Productos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Productos.Location = new System.Drawing.Point(229, 68);
            this.button_Productos.Name = "button_Productos";
            this.button_Productos.Size = new System.Drawing.Size(105, 39);
            this.button_Productos.TabIndex = 30;
            this.button_Productos.Text = "Productos";
            this.button_Productos.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_Productos.UseVisualStyleBackColor = true;
            // 
            // button_Clientes
            // 
            this.button_Clientes.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Clientes.Image = ((System.Drawing.Image)(resources.GetObject("button_Clientes.Image")));
            this.button_Clientes.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Clientes.Location = new System.Drawing.Point(118, 67);
            this.button_Clientes.Name = "button_Clientes";
            this.button_Clientes.Size = new System.Drawing.Size(105, 39);
            this.button_Clientes.TabIndex = 29;
            this.button_Clientes.Text = "Empleados";
            this.button_Clientes.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_Clientes.UseVisualStyleBackColor = true;
            this.button_Clientes.Click += new System.EventHandler(this.button_Clientes_Click);
            // 
            // button_Ventas
            // 
            this.button_Ventas.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Ventas.Image = ((System.Drawing.Image)(resources.GetObject("button_Ventas.Image")));
            this.button_Ventas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Ventas.Location = new System.Drawing.Point(7, 67);
            this.button_Ventas.Name = "button_Ventas";
            this.button_Ventas.Size = new System.Drawing.Size(105, 39);
            this.button_Ventas.TabIndex = 28;
            this.button_Ventas.Text = "Ventas";
            this.button_Ventas.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_Ventas.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-9, -3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(300, 61);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 27;
            this.pictureBox1.TabStop = false;
            // 
            // comboBox_Tipo_Empleado
            // 
            this.comboBox_Tipo_Empleado.FormattingEnabled = true;
            this.comboBox_Tipo_Empleado.Location = new System.Drawing.Point(6, 245);
            this.comboBox_Tipo_Empleado.Name = "comboBox_Tipo_Empleado";
            this.comboBox_Tipo_Empleado.Size = new System.Drawing.Size(198, 21);
            this.comboBox_Tipo_Empleado.TabIndex = 29;
            this.comboBox_Tipo_Empleado.SelectedIndexChanged += new System.EventHandler(this.comboBox_Tipo_Empleado_SelectedIndexChanged);
            // 
            // comboBox_Area_Empleado
            // 
            this.comboBox_Area_Empleado.FormattingEnabled = true;
            this.comboBox_Area_Empleado.Location = new System.Drawing.Point(210, 289);
            this.comboBox_Area_Empleado.Name = "comboBox_Area_Empleado";
            this.comboBox_Area_Empleado.Size = new System.Drawing.Size(87, 21);
            this.comboBox_Area_Empleado.TabIndex = 30;
            // 
            // comboBox_Puesto
            // 
            this.comboBox_Puesto.FormattingEnabled = true;
            this.comboBox_Puesto.Location = new System.Drawing.Point(210, 338);
            this.comboBox_Puesto.Name = "comboBox_Puesto";
            this.comboBox_Puesto.Size = new System.Drawing.Size(87, 21);
            this.comboBox_Puesto.TabIndex = 31;
            // 
            // label_BannerGuardado
            // 
            this.label_BannerGuardado.AutoSize = true;
            this.label_BannerGuardado.Location = new System.Drawing.Point(185, 64);
            this.label_BannerGuardado.Name = "label_BannerGuardado";
            this.label_BannerGuardado.Size = new System.Drawing.Size(0, 13);
            this.label_BannerGuardado.TabIndex = 32;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1052, 666);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.button_Config);
            this.Controls.Add(this.button_Compras);
            this.Controls.Add(this.button_Dpto);
            this.Controls.Add(this.button_Productos);
            this.Controls.Add(this.button_Clientes);
            this.Controls.Add(this.button_Ventas);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ABC Empleados";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox_ReciboVenta.ResumeLayout(false);
            this.groupBox_ReciboVenta.PerformLayout();
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ClienteVenta)).EndInit();
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Ventas)).EndInit();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox_Recibo.ResumeLayout(false);
            this.groupBox_Recibo.PerformLayout();
            this.groupBox_ClienteReporte.ResumeLayout(false);
            this.groupBox_ClienteReporte.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ClienteReporte)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Empleado)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ProdCompra)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Productos)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Cat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Dpto)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ComprasProductos)).EndInit();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.groupBox21.ResumeLayout(false);
            this.groupBox21.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.groupBox24.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Usuarios)).EndInit();
            this.groupBox23.ResumeLayout(false);
            this.groupBox23.PerformLayout();
            this.groupBox22.ResumeLayout(false);
            this.groupBox22.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            this.groupBox26.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ProductoCompra)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ProductoPrecio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_BodegaReporte)).EndInit();
            this.groupBox27.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Reporte)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_CatProductos)).EndInit();
            this.groupBox25.ResumeLayout(false);
            this.groupBox25.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox_ReciboVenta;
        private System.Windows.Forms.Label label_ReciboDeudaAnterior;
        private System.Windows.Forms.Label label_DuedaAnterior;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label_ReciboFecha;
        private System.Windows.Forms.Label label_ReciboUltimoPago;
        private System.Windows.Forms.Label label_ReciboDeudaTotal;
        private System.Windows.Forms.Label label_ReciboDeuda;
        private System.Windows.Forms.Label label_ReciboNombre;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.Label label_MensajeCliente;
        private System.Windows.Forms.TextBox textBox_BuscarClienteVenta;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.DataGridView dataGridView_ClienteVenta;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.Label label_PaginaVenta;
        private System.Windows.Forms.Button button_VtUltimo;
        private System.Windows.Forms.Button button_VtAnterior;
        private System.Windows.Forms.Button button_VtSiguiente;
        private System.Windows.Forms.Button button_VtPrimero;
        private System.Windows.Forms.Button button_ReciboVenta;
        private System.Windows.Forms.Label label_ProductoAgotado;
        private System.Windows.Forms.DataGridView dataGridView_Ventas;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.Label label_Deuda;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.CheckBox checkBox_Credito;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox textBox_Pagos;
        private System.Windows.Forms.Label label_Cambio;
        private System.Windows.Forms.Label label_SuCambio;
        private System.Windows.Forms.Label label_ImportesVentas;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button button_CancelarVenta;
        private System.Windows.Forms.Button button_Cobrar;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.Label label_MensajeVenta;
        private System.Windows.Forms.Button button_BuscarProducto;
        private System.Windows.Forms.TextBox textBox_BuscarProductos;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox_Recibo;
        private System.Windows.Forms.Label label_FechaPG;
        private System.Windows.Forms.Label label_ClienteUP;
        private System.Windows.Forms.Label label_ClienteSA;
        private System.Windows.Forms.Label label_ApellidoRB;
        private System.Windows.Forms.Label label_NombreRB;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox_ClienteReporte;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dataGridView_ClienteReporte;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox textBox_BuscarCliente;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox textBox_Apellido1;
        private System.Windows.Forms.Label label_Apellido1;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.RadioButton radioButton_IngresarEmpleado;
        private System.Windows.Forms.Button button_EliminarClientes;
        private System.Windows.Forms.TextBox textBox_Tipo_Empleado;
        private System.Windows.Forms.Label label_Tipo_Empleado;
        private System.Windows.Forms.Button button_Cancelar;
        private System.Windows.Forms.Button button_GuardarCliente;
        private System.Windows.Forms.Label label_Fecha_Nac;
        private System.Windows.Forms.TextBox textBox_Area_Empleado;
        private System.Windows.Forms.Label label_Area_Empleado;
        private System.Windows.Forms.TextBox textBox_Nombre1;
        private System.Windows.Forms.Label label_Nombre1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button_ImprCliente;
        private System.Windows.Forms.Label label_PaginasCliente;
        private System.Windows.Forms.Button button_UltimosClientes;
        private System.Windows.Forms.Button button_AnteriosClientes;
        private System.Windows.Forms.Button button_SiguientesClientes;
        private System.Windows.Forms.Button button_PrimerosClientes;
        private System.Windows.Forms.DataGridView dataGridView_Empleado;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.DataGridView dataGridView_ProdCompra;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox textBox_BuscarPDT;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label_PaginasPDT;
        private System.Windows.Forms.Button button_UltimaPDT;
        private System.Windows.Forms.Button button_AnteriorPDT;
        private System.Windows.Forms.Button button_SiguientePDT;
        private System.Windows.Forms.Button button_PrimeroPDT;
        private System.Windows.Forms.DataGridView dataGridView_Productos;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Panel panelCodigo;
        private System.Windows.Forms.ComboBox comboBox_Categorias;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox comboBox_DepartamentoPDT;
        private System.Windows.Forms.Label label_DepartamentoPDT;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox_DescripcionPDT;
        private System.Windows.Forms.Label label_DescripcionPDT;
        private System.Windows.Forms.Button button_CancelarPDT;
        private System.Windows.Forms.Button button_GuardarPDT;
        private System.Windows.Forms.TextBox textBox_PrecioVentaPDT;
        private System.Windows.Forms.Label label_PrecioVentaPDT;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox textBox_CoprasProductos;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.DataGridView dataGridView_Cat;
        private System.Windows.Forms.DataGridView dataGridView_Dpto;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Label label_Cat;
        private System.Windows.Forms.TextBox textBox_Cat;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label_Dpto;
        private System.Windows.Forms.TextBox textBox_Dpto;
        private System.Windows.Forms.RadioButton radioButton_Cat;
        private System.Windows.Forms.RadioButton radioButton_Dpto;
        private System.Windows.Forms.Button button_EliminarDpto;
        private System.Windows.Forms.Button button_DptoCancelar;
        private System.Windows.Forms.Button button_CuardarDpto;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox textBox_BuscarDpto;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.Label label_PaginasCompras;
        private System.Windows.Forms.Button button_UltimaCompra;
        private System.Windows.Forms.Button button_AnteriorCompra;
        private System.Windows.Forms.Button button_SiguienteCompra;
        private System.Windows.Forms.Button button_PrimerCompra;
        private System.Windows.Forms.DataGridView dataGridView_ComprasProductos;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Label label_ImprorteCompras;
        private System.Windows.Forms.Label label_ImportCompra;
        private System.Windows.Forms.TextBox textBox_PrecioCompra;
        private System.Windows.Forms.Label label_PrecioCmpra;
        private System.Windows.Forms.Button button_EliminarCompras;
        private System.Windows.Forms.TextBox textBox_DescpCompra;
        private System.Windows.Forms.Label label_DescpCompra;
        private System.Windows.Forms.Button button_CancelarCompras;
        private System.Windows.Forms.Button button_GuardarCompras;
        private System.Windows.Forms.TextBox textBox_CantidadCompra;
        private System.Windows.Forms.Label label_CantidadCompra;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.TextBox textBox_BuscarCompras;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Button button_db;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Button button_Reporte;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Button button_Cageros;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.GroupBox groupBox24;
        private System.Windows.Forms.DataGridView dataGridView_Usuarios;
        private System.Windows.Forms.GroupBox groupBox23;
        private System.Windows.Forms.RadioButton radioButton_Cajero;
        private System.Windows.Forms.RadioButton radioButton_Admin;
        private System.Windows.Forms.Label label_Contraseña;
        private System.Windows.Forms.TextBox textBox_Contraseña;
        private System.Windows.Forms.Label label_User;
        private System.Windows.Forms.TextBox textBox_Usuario;
        private System.Windows.Forms.Button button_EliminarUsuario;
        private System.Windows.Forms.TextBox textBox_ApellidoUser;
        private System.Windows.Forms.Label label_ApellidoUser;
        private System.Windows.Forms.Button button_CancelarUser;
        private System.Windows.Forms.Button button_GuardarUser;
        private System.Windows.Forms.TextBox textBox_TelefonoUser;
        private System.Windows.Forms.Label label_TelefonoUser;
        private System.Windows.Forms.TextBox textBox_NombreUser;
        private System.Windows.Forms.Label label_NombreUser;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.GroupBox groupBox26;
        private System.Windows.Forms.DataGridView dataGridView_ProductoCompra;
        private System.Windows.Forms.DataGridView dataGridView_ProductoPrecio;
        private System.Windows.Forms.DataGridView dataGridView_BodegaReporte;
        private System.Windows.Forms.GroupBox groupBox27;
        private System.Windows.Forms.DataGridView dataGridView_Reporte;
        private System.Windows.Forms.DataGridView dataGridView_CatProductos;
        private System.Windows.Forms.GroupBox groupBox25;
        private System.Windows.Forms.ComboBox comboBox_Opciones;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Button button_Config;
        private System.Windows.Forms.Button button_Compras;
        private System.Windows.Forms.Button button_Dpto;
        private System.Windows.Forms.Button button_Productos;
        private System.Windows.Forms.Button button_Clientes;
        private System.Windows.Forms.Button button_Ventas;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1_Fecha_Nac;
        private System.Windows.Forms.TextBox textBox_Puesto;
        private System.Windows.Forms.Label label_Puesto;
        private System.Windows.Forms.ComboBox comboBox_Puesto;
        private System.Windows.Forms.ComboBox comboBox_Area_Empleado;
        private System.Windows.Forms.ComboBox comboBox_Tipo_Empleado;
        private System.Windows.Forms.Label label_BannerGuardado;
    }
}

