﻿using Punto_de_ventas.Connection;
using Punto_de_ventas.ModelsClass;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto_de_ventas
{
    public partial class Form1 : Form
    {
        TextBoxEvent evento = new TextBoxEvent();
        Employee employee = new Employee();
        Tipos_Empleados tipo_emp = new Tipos_Empleados();
        private string accion = "insert", paginas = "4", deudaActual, pago, dia, fecha;

        

        public Form1()
        {
            InitializeComponent();
            /******
            CODIGO DE EMPLEADO
            *******/
            #region

            radioButton_IngresarEmpleado.Checked = true;
            radioButton_IngresarEmpleado.ForeColor = Color.DarkCyan;

            //esto ya esta al dar click al boton empleado

            tabControl1.SelectedIndex = 1;
            button_Clientes.Enabled = false;
            button_Ventas.Enabled = true;
            button_Productos.Enabled = true;
            button_Compras.Enabled = true;
            button_Dpto.Enabled = true;
            button_Compras.Enabled = true;

            comboBox_Tipo_Empleado.Items.AddRange(tipo_emp._getTipoEmpleado().ToArray());

            #endregion
        }

        

        /******
         CODIGO DE EMPLEADO
        *******/
        #region

        private void button_Clientes_Click(object sender, EventArgs e)
        {
            paginas = "1";
            accion = "insert";
            //Llamamos a la pagina numero 1 del tabControl1
            tabControl1.SelectedIndex = 1;
            //cargarDatos();
            button_Clientes.Enabled = false;
            button_Ventas.Enabled = true;
            button_Productos.Enabled = true;
            button_Compras.Enabled = true;
            button_Dpto.Enabled = true;
            button_Compras.Enabled = true;

            comboBox_Tipo_Empleado.Items.AddRange(tipo_emp._getTipoEmpleado().ToArray());

        }

        private void radioButton_IngresarEmpleado_CheckedChanged(object sender, EventArgs e)
        {
            radioButton_IngresarEmpleado.ForeColor = Color.DarkCyan;
            //radioButton_PagosDeudas.ForeColor = Color.Black;
            textBox_Apellido1.ReadOnly = false;
            textBox_Nombre1.ReadOnly = false;
            textBox_Tipo_Empleado.ReadOnly = false;
            textBox_Area_Empleado.ReadOnly = false;
            //textBox_BirthDate.ReadOnly = false;
            //textBox_ReportsTo.ReadOnly = false;
        }


        private void textBox_Apellido1_TextChanged(object sender, EventArgs e)
        {
            if (textBox_Apellido1.Text == "")
            {
                label_Apellido1.Text = "Primer Apellido";
                label_Apellido1.ForeColor = Color.LightSlateGray;
            }
            else
            {
                label_Apellido1.Text = "Apellido completo";
                label_Apellido1.ForeColor = Color.Green;
            }
        }

        private void textBox_Apellido1_KeyPress(object sender, KeyPressEventArgs e)
        {
            evento.textKeyPress(e);
        }

        private void textBox_Nombre1_TextChanged(object sender, EventArgs e)
        {
            if (textBox_Nombre1.Text == "")
            {
                label_Nombre1.Text = "Primer Nombre";
                label_Nombre1.ForeColor = Color.LightSlateGray;
            }
            else
            {
                label_Nombre1.Text = "Nombre completo";
                label_Nombre1.ForeColor = Color.Green;
            }
        }

        private void textBox_Nombre1_KeyPress(object sender, KeyPressEventArgs e)
        {
            evento.textKeyPress(e);
        }

        private void textBox_Tipo_Empleado_TextChanged(object sender, EventArgs e)
        {
            if (textBox_Tipo_Empleado.Text == "")
            {
                label_Tipo_Empleado.Text = "Tipo Empleado";
                label_Tipo_Empleado.ForeColor = Color.LightSlateGray;
            }
            else
            {
                label_Tipo_Empleado.Text = "Tipo empleado completo";
                label_Tipo_Empleado.ForeColor = Color.Green;
            }
        }

        private void textBox_Tipo_Empleado_KeyPress(object sender, KeyPressEventArgs e)
        {
            evento.textKeyPress(e);
        }

        private void textBox_Area_Empleado_TextChanged(object sender, EventArgs e)
        {
            if (textBox_Area_Empleado.Text == "")
            {
                label_Area_Empleado.Text = "Area Empleado";
                label_Area_Empleado.ForeColor = Color.LightSlateGray;
            }
            else
            {
                label_Area_Empleado.Text = "Area empleado completo";
                label_Area_Empleado.ForeColor = Color.Green;
            }
        }

        private void textBox_Area_Empleado_KeyPress(object sender, KeyPressEventArgs e)
        {
            evento.textKeyPress(e);
        }

        private void textBox_Puesto_TextChanged(object sender, EventArgs e)
        {
            if (textBox_Puesto.Text == "")
            {
                label_Puesto.Text = "Puesto";
                label_Puesto.ForeColor = Color.LightSlateGray;
            }
            else
            {
                label_Puesto.Text = "Puesto completo";
                label_Puesto.ForeColor = Color.Green;
            }
        }

        private void textBox_Puesto_KeyPress(object sender, KeyPressEventArgs e)
        {
            evento.textKeyPress(e);
        }

        ////ya no se usa este text box
        //private void textBox_BirthDate_TextChanged(object sender, EventArgs e)
        //{

        //}

        //private void textBox_BirthDate_KeyPress(object sender, KeyPressEventArgs e)
        //{
        //    evento.dateKeyPress(e);
        //}

        private void button_GuardarCliente_Click(object sender, EventArgs e)
        {
            if (radioButton_IngresarEmpleado.Checked)
            {
                guardarCliente();
                
            }
        }

        private void guardarCliente()
        {
            if (textBox_Apellido1.Text == "")
            {
                label_Apellido1.Text = "Ingrese el primer apellido";
                label_Apellido1.ForeColor = Color.Red;
                textBox_Apellido1.Focus();
            }
            else
            {
                if (textBox_Nombre1.Text == "")
                {
                    label_Nombre1.Text = "Ingrese el primer nombre";
                    label_Nombre1.ForeColor = Color.Red;
                    textBox_Nombre1.Focus();
                }
                else
                {
                    if (textBox_Tipo_Empleado.Text == "")
                    {
                        label_Tipo_Empleado.Text = "Ingrese el tipo de empleado";
                        label_Tipo_Empleado.ForeColor = Color.Red;
                        textBox_Tipo_Empleado.Focus();
                    }
                    else
                    {
                        if (textBox_Area_Empleado.Text == "")
                        {
                            label_Area_Empleado.Text = "Ingrese el area del empleado";
                            label_Area_Empleado.ForeColor = Color.Red;
                            textBox_Area_Empleado.Focus();
                        }
                        else
                        {
                            if (textBox_Puesto.Text == "")
                            {
                                label_Puesto.Text = "Ingrese el puesto";
                                label_Puesto.ForeColor = Color.Red;
                                textBox_Puesto.Focus();
                            }
                            else
                            {
                                if (dateTimePicker1_Fecha_Nac.Text == "")
                                {
                                    label_Fecha_Nac.Text = "Ingrese la fecha";
                                    label_Fecha_Nac.ForeColor = Color.Red;
                                    dateTimePicker1_Fecha_Nac.Focus();
                                }
                                else
                                {
                                    string apellido1 = textBox_Apellido1.Text;
                                    string nombre1 = textBox_Nombre1.Text;
                                    string tipo_empleado = textBox_Tipo_Empleado.Text;
                                    string area_empleado = textBox_Area_Empleado.Text;
                                    string puesto = textBox_Puesto.Text;
                                    DateTime fecha_nac = Convert.ToDateTime(dateTimePicker1_Fecha_Nac.Text);

                                    if (accion == "insert")
                                    {
                                        employee.InsertEmployee(apellido1, nombre1, tipo_empleado, area_empleado, puesto, fecha_nac);
                                        //label_BannerGuardado.Text = "Guardado";
                                        //label_BannerGuardado.ForeColor = Color.Green;
                                        textBox_Apellido1.Text = " ";
                                        textBox_Nombre1.Text = " ";
                                        textBox_Tipo_Empleado.Text = " ";
                                        textBox_Area_Empleado.Text = " ";
                                        textBox_Puesto.Text = " ";
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        private void comboBox_Tipo_Empleado_SelectedIndexChanged(object sender, EventArgs e)
        {
            label_BannerGuardado.Text = "Guardado";
            tipo_emp._getTipoEmpleado();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        #endregion
    }
}
