﻿using LinqToDB;
using Punto_de_ventas.Connection;
using Punto_de_ventas.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto_de_ventas.ModelsClass
{
    public class Tipos_Empleados : Conexion
    {
        public List<tipo_empleado> getTipoEmpleado()
        {
            var query = from e in Tipos_Empleados
                        select e;
            return query.ToList();
        }

        public List<string> _getTipoEmpleado()
        {
            var query = from e in Tipos_Empleados
                        select e.Tipo_empleado;
            return query.ToList();
        }
    }
}

//where 
