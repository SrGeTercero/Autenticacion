﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto_de_ventas.ModelsClass
{
    public class TextBoxEvent
    {
        public void textKeyPress(KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar)) { e.Handled = false; }
            else if (char.IsControl(e.KeyChar)) { e.Handled = false; }
            else if (char.IsSeparator(e.KeyChar)) { e.Handled = false; }
            else { e.Handled = true; }

        }

        public void dateKeyPress(KeyPressEventArgs e)
        {
            //switch (e.KeyChar)
            //{
            //    case (char)47:
            //        e.Handled = false;
            //        break;
            //    default:
            //        e.Handled = true;
            //        break;
            //}
            if (char.IsDigit(e.KeyChar)) { e.Handled = false; }
            else if (char.IsControl(e.KeyChar)) { e.Handled = false; }
            else if (e.KeyChar == '/') { e.Handled = false; }
            else { e.Handled = true; }
        }

        public void numberDecimalKeyPress (TextBox textbox, KeyPressEventArgs e)
        {

        }


    }
}
