﻿using LinqToDB;
using Punto_de_ventas.Connection;
using Punto_de_ventas.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto_de_ventas.ModelsClass
{
    public class Employee : Conexion
    {
        public List<Employees> getEmployees()
        {
            var query = from e in Employee
                        select e;
            return query.ToList();
        }

        public void InsertEmployee(string apellido1, string nombre1, string tipo_empleado, string area_empleado, 
            string puesto, DateTime fecha_nac)
        {
            using (var db = new Conexion())
            {
                db.Insert(new Employees()
                {
                    Apellido1=apellido1,
                    Nombre1=nombre1,
                    Tipo_empleado=tipo_empleado,
                    Area_empleado=area_empleado,
                    Puesto=puesto,
                    Fecha_nac=fecha_nac
                });
            }
        }


    }
}
