﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using WebAPI_2.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebAPI_2.Controllers
{
    [Route("api/product")]
    public class productController : Controller
    {
        private DataContext db = new DataContext();

        [Produces("application/json")]
        [HttpGet("findall")]
        public async Task<IActionResult> FindAll()
        {
            try
            {
                var products = db.product.ToList();
                return Ok(products);
            }
            catch
            {
                return BadRequest();
            }
        }
    }
}
