﻿using WebAPI_2_Client.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace WebAPI_2_Client
{
    public class productRestClientModel
    {
        private string BASE_URL = "http://localhost:54646/api/product";
        public Task<HttpResponseMessage> FindAll()
        {
            try
            {
                var client = new HttpClient();
                client.BaseAddress = new Uri(BASE_URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                return client.GetAsync("FindAll");
            }
            catch
            {
                return null;
            }
        }
    }
}
