﻿using WebAPI_2_Client.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace WebAPI_2_Client
{
    class Program
    {
        static void Main(string[] args)
        {

            var httpResponseMessage = new productRestClientModel().FindAll().Result;

                
            HttpStatusCode httpStatusCode = httpResponseMessage.StatusCode;
            Console.WriteLine("Status Code: " + httpStatusCode);

            bool isSuccessStatusCode = httpResponseMessage.IsSuccessStatusCode;
            Console.WriteLine("IsSuccessStatusCode: " + isSuccessStatusCode);

            List<product> products = httpResponseMessage.Content.ReadAsAsync<List<product>>().Result;
            Console.WriteLine("Product list");
            foreach (var product in products)
            {
                Console.WriteLine("Id: " + product.id);
                Console.WriteLine("Name: " + product.name);
                Console.WriteLine("Price " + product.price);
                Console.WriteLine("Quantity: " + product.quantity);
                Console.WriteLine("Status: " + product.status);
                Console.WriteLine("============================");
            }
            Console.ReadLine();
        }
    }
}
